
public class TestProtobuf {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//SearchResults.Builder var = SearchResults.newBuilder();
		
		System.out.println("abc");
		
	}

}
