Setup SBT environment
---------------------

https://pgi.imeetcentral.com/pgiidentityservice/folder/WzIwLDg4OTQ2NDBd/WzIsNTIxMDYwMDNd/

MacOS Install
-------------

	brew update
	brew install ruby (if not already done)
	gem install bundler (if not already done)
	brew install sbt (if not already done)

Any environment variables should also go in startGMSearch.

Windows Install
---------------

	Open Powershell
	
	set-executionpolicy remotesigned -s cu
	iex (new-object net.webclient).downloadstring('https://get.scoop.sh')
	
	Command line

	scoop install sbt (if not already done)
	scoop bucket add extras
	scoop install oraclejdk (if not already done)
	scoop install docker (if not already done)
	scoop install ruby (if not already done)
	
	gem install bundler (if not already done)
	

If you intend to install Docker containers from Windows, do the following:

	Install VirtualBox (https://www.virtualbox.org/wiki/Downloads)
	scoop install docker docker-machine
	Enable virtualization in your BIOS
	docker-machine create --driver virtualbox --virtualbox-memory 3072 --virtualbox-disk-size 50000 dev
	docker-machine start dev
	docker login

Run
---

	startGMSearch (or startGMSearch.cmd on Windows)
	run
	
Documentation
-------------

To publish the documentation run

    cd src/jekyll
    bundle install (if not already done)
    bundle exec jekyll build --destination ../../public/documentation/

The documentation will be at https://localost:9444/docs.

Docker
------

Create a docker image

	git tag 0.X
	sbt docker:publishLocal
	sbt docker:publish

Setup Elastic Search
--------------------
    brew install elasticsearch
    elasticsearch

Separate terminal

    export ES_HOST=http://localhost:9200
    git clone ssh://git@bitbucket.pgi-tools.com/id/meetingroom-esmappings.git
    cd neetingroom-esmappings
    ./meetingroom-esmappings.sh
    git clonse ssh://git@bitbucket.pgi-tools.com/id/contact-esmappings.git
    cd contact-esmappings
    ./contact-esmappings.sh
    
Example meetingroom

    curl -XPUT http://localhost:9200/meetingrooms/_doc/12345 -H "Content-Type:application/json" -d '
    {
      "docType": "meetingrooms",
      "meetingRoomName": "KevinOsborn",
      "meetingRoomUrlBase": "http://myglobalmeet.itdev.local",
      "meetingRoomUrlRoomName": "kevinosborn",
      "meetingRoomUrl": "http://myglobalmeet.itdev.local/kevinosborn",
      "meetingRoomUrlOrig": "http://myglobalmeet.itdev.local/kevinosborn",
      "meetingRoomType": "globalmeet4",
      "webMeetingServer": "securemeetingdev.pgilab.net",
      "ownerEmail": "kevin.osborn@pgi.com",
      "conferenceType": "Web and Audio",
      "profileImageUrls": [
        {
          "imageUrl": "https://test88.data/image1.jpg",
          "isDefault": true
        }
      ],
      "conferenceId": "7898004",
      "webMeetingServerRegion": "us-gmweb-1",
      "userGroupId": "229339",
      "brandId": "1",
      "ownerGivenName": "Kevin",
      "ownerFamilyName": "Osborn",
      "ownerName_westernOrder": "Kevin Osborn",
      "ownerName_easternOrder": "Osborn Kevin",
      "defaultLanguageCode": "en",
      "inactive": false
    }
    '

Delete all meetingrooms

    curl -XPOST http://localhost:9200/meetingrooms/_delete_by_query?conflicts=proceed -H "Content-Type:application/json" -d '
    {
      "query": {
        "match_all": {}
       }
    }
    '

Example contact

    curl -XPUT http://localhost:9200/contacts/_doc/12345 -H "Content-Type:application/json" -d '
    {
      "docType": "contacts",
      "userGroupId": "229339",
      "ownerEmail": "kevin.osborn@pgi.com",
      "ownerGivenName": "Kevin",
      "ownerFamilyName": "Osborn",
      "ownerName_westernOrder": "Kevin Osborn",
      "ownerName_easternOrder": "Osborn Kevin",
      "profileImageUrls": [
        {
          "imageUrl": "https://test88.data/image1.jpg",
          "isDefault": true
        }
      ],
      "jobTitle": "Software Manager",
      "phoneNumbers": [
        {
          "type": "mobile",
          "value": "+1 (555) 867-5309"
        }
      ],
      "address": null,
      "appInfo": [
        {
          "kazoo": {
            "accountId": "12345",
            "userId": "123456"
          }
        },
        {
          "bazoo": {
            "accountId": "qwerty",
            "userId": "qazxsw"
          }
        }
        ],
      "inactive": false
    }
    '

Delete all contacts

    curl -XPOST http://localhost:9200/contacts/_delete_by_query?conflicts=proceed -H "Content-Type:application/json" -d '
    {
      "query": {
        "match_all": {}
       }
    }
    '