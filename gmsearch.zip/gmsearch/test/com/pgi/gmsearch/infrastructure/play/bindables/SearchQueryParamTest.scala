package com.pgi.gmsearch.infrastructure.play.bindables

import java.net.{URLDecoder, URLEncoder}
import java.nio.charset.StandardCharsets

import org.scalatest.FunSuite


class SearchQueryParamTest extends FunSuite {

  test("bind should return seq of SearchQueryParam with value decoded") {
    val key: String = "fq"
    val params: Map[String, Seq[String]] = Map("fq.email" -> Seq("bob%40bob.com","rob@rob.com"), "fq.companyid" -> Seq("123"))
    val result: Option[Either[String, Seq[SearchQueryParam]]] = SearchQueryParam.searchQueryParamsBinder.bind(key, params)

    val searchQueryParams: Seq[SearchQueryParam] = result.get.getOrElse(Seq.empty)
    assert(2 == searchQueryParams.size)
    assert("email" == searchQueryParams(0).key)
    assert(2 == searchQueryParams(0).value.size)
    assert("bob%40bob.com" == searchQueryParams(0).value.head)
    assert("rob@rob.com" == searchQueryParams(0).value.toSeq(1))

    assert("companyid" == searchQueryParams(1).key)
    assert("123" == searchQueryParams(1).value.head)
  }

  test("unbind should return query parameters with value encoded") {
    val key: String = "fq"
    val searchQueryParams: Seq[SearchQueryParam] = Seq(new SearchQueryParam("email", Set("bob@bob.com")), new SearchQueryParam("companyid", Set("123")))
    val result: String = SearchQueryParam.searchQueryParamsBinder.unbind(key, searchQueryParams)

    assert("fq.email=" + URLEncoder.encode("bob@bob.com", StandardCharsets.UTF_8.name) + "&fq.companyid=123" == result)
  }
}
