package com.pgi.gmsearch.search.test

import com.pgi.playframework.infrastructure.kamon.KamonHelpers
import com.pgi.playframework.infrastructure.play.essentialactions.DefaultAccessTokenHandler
import com.pgi.playframework.test.PortGetter
import javax.inject.Inject
import play.api.Configuration
import play.api.cache.{AsyncCacheApi, NamedCache}
import play.api.libs.ws.WSClient

import scala.concurrent.ExecutionContext

class TestAccessTokenHandler @Inject() (conf: Configuration, ws: WSClient,
    @NamedCache("oauth2-discovery-url-cache") discoveryCache: AsyncCacheApi, portGetter: PortGetter)
  (implicit ec: ExecutionContext) extends DefaultAccessTokenHandler(conf, ws, discoveryCache)(ec) with KamonHelpers {
  override lazy val discoveryUrl = s"http://localhost:${portGetter.getPort}/.well-known/openid-configuration"
}