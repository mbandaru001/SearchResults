package com.pgi.gmsearch.search.test

import play.api.libs.json.Json

trait TestValues {
  final val PreHlTag = "[hl+]"
  final val PostHlTag = "[+hl]"

  val testMeetingRoomId = "1377769"
  val testClientId = "987654"

  val testCorporateEntityId = "test123"
  val testMeetingRoomName = "JonathanMeeting"
  val testMeetingRoomUrlBase = "https://myglobalmeet.itdev.local"
  val testMeetingRoomUrlRoomName = "JonathanDev"
  val testMeetingRoomUrl = "https://myglobalmeet.itdev.local/JonathanDev"
  val testMeetingRoomType = "globalmeet5"
  val testWebMeetingServer = "web-na.globalmeet.com"
  val testOwnerEmail = "jonathan.pearson@pgi.com"
  val testOwnerGivenName = "Jonathan"
  val testOwnerFamilyName = "Pearson"
  val testOwnerNameWesternOrder = "Jonathan Pearson"
  val testOwnerNameEasternOrder = "Pearson Jonathan"
  val testConferenceType = "WebAndAudio"
  val testBrandId = "9015"
  val testImageUrl = "https://test88.data/image1.jpg"
  val imageUrls = Json.arr(Json.obj("imageUrl" -> testImageUrl, "isDefault" -> true))
  val images = Json.arr(Json.obj("imageUrl" -> testImageUrl, "isDefault" -> true))
  val testConferenceId = "123456"
  val testDefaultLanguageCode = "en"
  val testVrcUrl = "123456@127.0.0.1"
  val testWebMeetingServerRegion = "apac"
  val testMeetingRooms = Json.arr(Json.obj("meetingRoomId" -> "123", "meetingRoomName" -> testMeetingRoomUrlRoomName, "meetingRoomUrl" -> testMeetingRoomUrl, "meetingRoomType" -> "globalmeet5"))
  val testJobTitle = "Software Engg. II"
  val testPhones = Json.arr(Json.obj("number" -> "+12345678901;ext=123", "phoneType" -> "mobile", "isDefault" -> true))
  val testAddress = Json.obj("localParts" -> Json.arr("123 Red Keep"), "city" -> "King's Landing", "region" -> "The South", "country" -> "Westeros")
  val testAppInfo = Json.obj("Kazoo" -> Json.arr("{\"accountId\":\"12345\",\"userId\":\"09876\"}"))

  val testEsMeetingRoomResponseSource = Json.obj(
    "docType" -> "meetingrooms",
    "meetingRoomName" -> testMeetingRoomName,
    "meetingRoomUrlBase" -> testMeetingRoomUrlBase,
    "meetingRoomUrlRoomName" -> testMeetingRoomUrlRoomName,
    "meetingRoomUrl" -> testMeetingRoomUrl,
    "meetingRoomType" -> testMeetingRoomType,
    "webMeetingServer" -> testWebMeetingServer,
    "ownerEmail" -> testOwnerEmail,
    "ownerGivenName" -> testOwnerGivenName,
    "ownerFamilyName" -> testOwnerFamilyName,
    "ownerName_westernOrder" -> testOwnerNameWesternOrder,
    "ownerName_easternOrder" -> testOwnerNameEasternOrder,
    "conferenceType" -> testConferenceType,
    "brandId" -> testBrandId,
    "profileImageUrls" -> imageUrls,
    "conferenceId" -> testConferenceId,
    "defaultLanguageCode" -> testDefaultLanguageCode,
    "vrcUrl" -> testVrcUrl,
    "webMeetingServerRegion" -> testWebMeetingServerRegion,
    "inactive" -> false
  )

  val testEsContactResponseSource = Json.obj(
    "docType" -> "contacts",
    "ownerEmail" -> testOwnerEmail,
    "ownerGivenName" -> testOwnerGivenName,
    "ownerFamilyName" -> testOwnerFamilyName,
    "ownerName_westernOrder" -> testOwnerNameWesternOrder,
    "ownerName_easternOrder" -> testOwnerNameEasternOrder,
    "profileImageUrls" -> imageUrls,
    "meetingRooms" -> testMeetingRooms,
    "jobTitle" -> testJobTitle,
    "phones" -> testPhones,
    "address" -> testAddress,
    "appInfo" -> testAppInfo,
    "inactive" -> false
  )

  val testInactiveEsMeetingRoomResponseSource = Json.obj(
    "docType" -> "meetingrooms",
    "meetingRoomName" -> testMeetingRoomName,
    "meetingRoomUrlBase" -> testMeetingRoomUrlBase,
    "meetingRoomUrlRoomName" -> testMeetingRoomUrlRoomName,
    "meetingRoomUrl" -> testMeetingRoomUrl,
    "meetingRoomType" -> testMeetingRoomType,
    "webMeetingServer" -> testWebMeetingServer,
    "ownerEmail" -> testOwnerEmail,
    "ownerGivenName" -> testOwnerGivenName,
    "ownerFamilyName" -> testOwnerFamilyName,
    "ownerName_westernOrder" -> testOwnerNameWesternOrder,
    "ownerName_easternOrder" -> testOwnerNameEasternOrder,
    "conferenceType" -> testConferenceType,
    "brandId" -> testBrandId,
    "profileImageUrls" -> imageUrls,
    "conferenceId" -> testConferenceId,
    "defaultLanguageCode" -> testDefaultLanguageCode,
    "vrcUrl" -> testVrcUrl,
    "webMeetingServerRegion" -> testWebMeetingServerRegion,
    "inactive" -> true
  )

  val testInactiveEsContactResponseSource = Json.obj(
    "docType" -> "contacts",
    "ownerEmail" -> testOwnerEmail,
    "ownerGivenName" -> testOwnerGivenName,
    "ownerFamilyName" -> testOwnerFamilyName,
    "ownerName_westernOrder" -> testOwnerNameWesternOrder,
    "ownerName_easternOrder" -> testOwnerNameEasternOrder,
    "profileImageUrls" -> imageUrls,
    "meetingRooms" -> testMeetingRooms,
    "jobTitle" -> testJobTitle,
    "phones" -> testPhones,
    "address" -> testAddress,
    "appInfo" -> testAppInfo,
    "inactive" -> true
  )

  val testMeetingRoomDetails = Json.obj(
    "meetingRoomName" -> testMeetingRoomName,
    "meetingRoomUrl" -> testMeetingRoomUrl,
    "meetingRoomType" -> testMeetingRoomType,
    "webMeetingServer" -> testWebMeetingServer,
    "ownerEmail" -> testOwnerEmail,
    "ownerGivenName" -> testOwnerGivenName,
    "ownerFamilyName" -> testOwnerFamilyName,
    "conferenceType" -> testConferenceType,
    "brandId" -> testBrandId,
    "images" -> images,
    "conferenceId" -> testConferenceId,
    "defaultLanguageCode" -> testDefaultLanguageCode,
    "vrcUrl" -> testVrcUrl,
    "webMeetingServerRegion" -> testWebMeetingServerRegion
  )

  val testContactSearchResponseMetadata = Json.obj(
    "email" -> testOwnerEmail,
    "givenNamme" -> testOwnerGivenName,
    "familyName" -> testOwnerFamilyName,
    "meetingRooms" -> testMeetingRooms,
    "jobTitle" -> testJobTitle,
    "phones" -> testPhones,
    "address" -> testAddress,
    "appInfo" -> testAppInfo,
  )

  val testContactDetails = Json.obj(
    "givenName" -> testOwnerGivenName,
    "familyName" -> testOwnerFamilyName,
    "email" -> testOwnerEmail,
    "jobTitle" -> testJobTitle,
    "images" -> images,
    "phones" -> testPhones,
    "address" -> testAddress,
    "meetingRooms" -> testMeetingRooms,
    "appInfo" -> testAppInfo
  )

  val testMeetingRoomResponse = Json.obj(
    "id" -> testMeetingRoomId,
    "resourceUri" -> s"/meetingrooms/$testMeetingRoomId",
    "resourceType" -> "MeetingRoom",
    "details" -> testMeetingRoomDetails
  )

  val testContactResponse = Json.obj(
    "id" -> testClientId,
    "resourceUri" -> s"/contacts/$testClientId",
    "resourceType" -> "Contact",
    "details" -> testContactDetails
  )

  val testMeetingRoomResponseWithIdsOnly = Json.obj(
    "id" -> testMeetingRoomId,
    "resourceUri" -> s"/meetingrooms/$testMeetingRoomId",
    "resourceType" -> "MeetingRoom",
  )

  val testContactResponseWithIdsOnly = Json.obj(
    "id" -> testClientId,
    "resourceUri" -> s"/contacts/$testClientId",
    "resourceType" -> "Contact",
  )

  val testMeetingSearchResponseMetadata = Json.obj(
    "meetingRoomType" -> testMeetingRoomType,
    "webMeetingServer" -> testWebMeetingServer,
    "conferenceType" -> testConferenceType,
    "conferenceId" -> testConferenceId
  )

  val testMeetingSearchResponseDetailsWesternOrder = Json.obj(
    "title" -> testOwnerNameWesternOrder,
    "secondaryTitle" -> testMeetingRoomUrl,
    "externalUrl" -> testMeetingRoomUrl,
    "imageUrl" -> testImageUrl,
    "metadata" -> testMeetingSearchResponseMetadata
  )

  val testContactSearchResponseDetailsWesternOrder = Json.obj(
    "title" -> testOwnerNameWesternOrder,
    "secondaryTitle" -> testOwnerEmail,
    "imageUrl" -> testImageUrl,
    "metadata" -> testContactSearchResponseMetadata
  )

  val testMeetingSearchResponseDetailsEasternOrder = Json.obj(
  "title" -> testOwnerNameEasternOrder,
  "secondaryTitle" -> testMeetingRoomUrl,
  "externalUrl" -> testMeetingRoomUrl,
  "imageUrl" -> testImageUrl,
  "metadata" -> testMeetingSearchResponseMetadata
  )

  val testContactSearchResponseDetailsEasternOrder = Json.obj(
    "title" -> testOwnerNameEasternOrder,
    "secondaryTitle" -> testOwnerEmail,
    "imageUrl" -> testImageUrl,
    "metadata" -> testContactSearchResponseMetadata
  )

  val testMeetingSearchResponseWesternOrder = Json.obj(
    "id" -> testMeetingRoomId,
    "resourceUri" -> s"/meetingrooms/$testMeetingRoomId",
    "resourceType" -> "MeetingRoom",
    "title" -> testOwnerNameWesternOrder,
    "secondaryTitle" -> testMeetingRoomUrl,
    "externalUrl" -> testMeetingRoomUrl,
    "imageUrl" -> testImageUrl,
    "metadata" -> testMeetingSearchResponseMetadata,
    "inactive" -> false
  )

  val testContactSearchResponseWesternOrder = Json.obj(
    "id" -> testClientId,
    "resourceUri" -> s"/contacts/$testClientId",
    "resourceType" -> "Contact",
    "title" -> testOwnerNameWesternOrder,
    "secondaryTitle" -> testOwnerEmail,
    "imageUrl" -> testImageUrl,
    "metadata" -> testContactSearchResponseMetadata,
    "inactive" -> false
  )

  val testMeetingSearchResponseEasternOrder = Json.obj(
    "id" -> testMeetingRoomId,
    "resourceUri" -> s"/meetingrooms/$testMeetingRoomId",
    "resourceType" -> "MeetingRoom",
    "details" -> testMeetingSearchResponseDetailsEasternOrder
  )

  val testContactSearchResponseEasternOrder = Json.obj(
    "id" -> testClientId,
    "resourceUri" -> s"/contacts/$testClientId",
    "resourceType" -> "Contact",
    "details" -> testContactSearchResponseDetailsEasternOrder
  )

  val testMeetingSearchResponseWithIdsOnly = Json.obj(
    "id" -> testMeetingRoomId,
    "resourceUri" -> s"/meetingrooms/$testMeetingRoomId",
    "resourceType" -> "MeetingRoom"
  )

  val testContactSearchResponseWithIdsOnly = Json.obj(
    "id" -> testClientId,
    "resourceUri" -> s"/contacts/$testClientId",
    "resourceType" -> "Contact"
  )

  val testMeetingSearchResponseListWesternOrder = Json.obj(
    "totalCount" -> 1,
    "items" -> Seq(testMeetingSearchResponseWesternOrder)
  )

  val testContactSearchResponseListWesternOrder = Json.obj(
    "totalCount" -> 1,
    "items" -> Seq(testContactSearchResponseWesternOrder)
  )

  val testSearchResponseListWesternOrder = Json.obj(
    "totalCount" -> 2,
    "items" -> Seq(testMeetingSearchResponseWesternOrder, testContactSearchResponseWesternOrder)
  )

  val testSuggestResponseListWesternOrder = Json.arr(
    testMeetingSearchResponseWesternOrder,
    testContactSearchResponseWesternOrder
  )

  val testMeetingSearchResponseListEasternOrder = Json.obj(
    "totalCount" -> 1,
    "items" -> Seq(testMeetingSearchResponseEasternOrder)
  )

  val testContactSearchResponseListEasternOrder = Json.obj(
    "totalCount" -> 1,
    "items" -> Seq(testContactSearchResponseEasternOrder)
  )

  val testMeetingSearchResponseListWithIdsOnly = Json.obj(
    "totalCount" -> 1,
    "items" -> Seq(testMeetingSearchResponseWithIdsOnly)
  )

  val testContactSearchResponseListWithIdsOnly = Json.obj(
    "totalCount" -> 1,
    "items" -> Seq(testContactSearchResponseWithIdsOnly)
  )
}
