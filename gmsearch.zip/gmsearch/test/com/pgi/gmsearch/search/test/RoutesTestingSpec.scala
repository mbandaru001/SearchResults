import com.pgi.gmsearch.search.api.SearchController
import com.pgi.gmsearch.search.test.{GMSearchTestApplicationBuilder, TestAccessTokenHandler, TestValues}
import com.pgi.playframework.infrastructure.play.essentialactions.AccessTokenHandler
import com.pgi.playframework.test.{AuthData, ControllerHelpers, PortGetter}
import org.elasticsearch.client.RestHighLevelClient
import org.mockito.Mockito.when
import org.scalatestplus.mockito.MockitoSugar
import org.scalatestplus.play.PlaySpec
import org.scalatestplus.play.guice.GuiceOneServerPerSuite
import play.api.Application
import play.api.inject.bind
import play.api.test.FakeRequest
import play.api.test.Helpers._

class RoutesTestingSpec extends PlaySpec with MockitoSugar with GMSearchTestApplicationBuilder with GuiceOneServerPerSuite {

  val portGetter = mock[PortGetter]
  val esRestClient = mock[RestHighLevelClient]

  override def fakeApplication(): Application = getBuilder.overrides(bind[RestHighLevelClient].toInstance(esRestClient)).
    overrides(bind[AccessTokenHandler].to[TestAccessTokenHandler], bind[PortGetter].toInstance(portGetter)).build

  "Root Controller" should {
    "route to search with double escaped query param value should not return INTERNAL_SERVER_ERROR" in {
      // 11%25%25 should be decoded by play framework as 11%%
      val result = route(app, FakeRequest(GET, "/search?hl=false&size=10&idsOnly=false&t=contacts&fq.companyId=11%25%25&q=doug%2B%2B&from=0&nameOrder=")
        .withHeaders("Authorization" -> s"Bearer ${createAccessToken(AuthData.issuer, Seq("gmsearch"): _*).serialize}")).get
      status(result) must not be INTERNAL_SERVER_ERROR
    }
  }
}
