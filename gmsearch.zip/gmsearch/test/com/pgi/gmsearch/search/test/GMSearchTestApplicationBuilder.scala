package com.pgi.gmsearch.search.test

import com.pgi.playframework.test.AuthenticatedApplicationBuilder
import play.api.inject.guice.GuiceApplicationBuilder

trait GMSearchTestApplicationBuilder extends AuthenticatedApplicationBuilder {
  override def getBuilder: GuiceApplicationBuilder =
    super.getBuilder.disable[play.modules.swagger.SwaggerModule]
}
