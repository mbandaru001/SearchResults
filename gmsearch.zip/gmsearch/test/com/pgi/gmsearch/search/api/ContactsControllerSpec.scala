package com.pgi.gmsearch.search.api

import com.fasterxml.jackson.core.JsonFactory
import com.pgi.gmsearch.contacts.api.ContactsController
import com.pgi.gmsearch.search.test.{GMSearchTestApplicationBuilder, TestAccessTokenHandler, TestValues}
import com.pgi.playframework.infrastructure.play.essentialactions.AccessTokenHandler
import com.pgi.playframework.test.{ControllerHelpers, PortGetter}
import org.elasticsearch.action.ActionListener
import org.elasticsearch.action.search.{SearchRequest, SearchResponse}
import org.elasticsearch.client.{RequestOptions, RestHighLevelClient}
import org.elasticsearch.common.xcontent.json.JsonXContentParser
import org.elasticsearch.common.xcontent.{DeprecationHandler, NamedXContentRegistry}
import org.mockito.ArgumentMatchers.any
import org.mockito.Mockito.when
import org.mockito.invocation.InvocationOnMock
import org.scalatestplus.mockito.MockitoSugar
import org.scalatestplus.play.PlaySpec
import org.scalatestplus.play.guice.GuiceOneServerPerSuite
import play.api.Application
import play.api.inject.bind
import play.api.libs.json.Json
import play.api.test.Helpers._

class ContactsControllerSpec extends PlaySpec with MockitoSugar with GMSearchTestApplicationBuilder
    with ControllerHelpers with GuiceOneServerPerSuite with TestValues {
  val portGetter = mock[PortGetter]

  val esRestClient = mock[RestHighLevelClient]

  val injector = app.injector
  val contactsController = injector.instanceOf[ContactsController]

  def getPort = port
  when(portGetter.getPort).thenReturn(getPort)

  override def fakeApplication(): Application = getBuilder.overrides(bind[RestHighLevelClient].toInstance(esRestClient)).
    overrides(bind[AccessTokenHandler].to[TestAccessTokenHandler], bind[PortGetter].toInstance(portGetter)).build

  var searchResponse: SearchResponse = _
  when(esRestClient.searchAsync(any[SearchRequest], any[RequestOptions], any[ActionListener[SearchResponse]])).
      thenAnswer((invocation: InvocationOnMock) => {
        val callback = invocation.getArgument(2).asInstanceOf[(ActionListener[SearchResponse])]
        callback.onResponse(searchResponse)
      })

  "Calling the get method with client id" must {
    "return JSON with contact details" in {
      val esResponse = Json.obj(
        "hits" -> Json.obj(
          "hits" -> Json.arr(
            Json.obj(
              "_index" -> "contacts:x.y.z",
              "_id" -> testClientId,
              "_source" -> testEsContactResponseSource
            )
          )
        )
      )
      searchResponse = SearchResponse.fromXContent(new JsonXContentParser(NamedXContentRegistry.EMPTY,
        DeprecationHandler.THROW_UNSUPPORTED_OPERATION, new JsonFactory().createParser(esResponse.toString())))

      val result = call(contactsController.getContact(testClientId, Seq.empty, idsOnly = false),
        generateFakeGetRequestWithScope("gmsearch"))
      status(result) mustBe OK
      contentAsJson(result) mustBe testContactResponse
    }
    "return JSON with only the client id" in {
      val esResponse = Json.obj(
        "hits" -> Json.obj(
          "hits" -> Json.arr(
            Json.obj(
              "_index" -> "contacts",
              "_id" -> testClientId
            )
          )
        )
      )
      searchResponse = SearchResponse.fromXContent(new JsonXContentParser(NamedXContentRegistry.EMPTY,
        DeprecationHandler.THROW_UNSUPPORTED_OPERATION, new JsonFactory().createParser(esResponse.toString())))

      val result = call(contactsController.getContact(testClientId, Seq.empty, idsOnly = true),
        generateFakeGetRequestWithScope("gmsearch"))
      status(result) mustBe OK
      contentAsJson(result) mustBe testContactResponseWithIdsOnly
    }
    "return not found error when client id is unknown" in {
      val esResponse = Json.obj(
        "hits" -> Json.obj(
          "hits" -> Json.arr()
        )
      )
      searchResponse = SearchResponse.fromXContent(new JsonXContentParser(NamedXContentRegistry.EMPTY,
        DeprecationHandler.THROW_UNSUPPORTED_OPERATION, new JsonFactory().createParser(esResponse.toString())))

      val result = call(contactsController.getContact(testClientId, Seq.empty, idsOnly = false),
        generateFakeGetRequestWithScope("gmsearch"))
      status(result) mustBe NOT_FOUND
    }
  }

}
