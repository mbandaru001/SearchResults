package com.pgi.gmsearch.search.api

import com.fasterxml.jackson.core.JsonFactory
import com.pgi.gmsearch.meetingrooms.api.MeetingRoomController
import com.pgi.gmsearch.search.test.{GMSearchTestApplicationBuilder, TestAccessTokenHandler, TestValues}
import com.pgi.playframework.infrastructure.play.essentialactions.AccessTokenHandler
import com.pgi.playframework.test.{ControllerHelpers, PortGetter}
import org.elasticsearch.action.ActionListener
import org.elasticsearch.action.search.{SearchRequest, SearchResponse}
import org.elasticsearch.client.{RequestOptions, RestHighLevelClient}
import org.elasticsearch.common.xcontent.json.JsonXContentParser
import org.elasticsearch.common.xcontent.{DeprecationHandler, NamedXContentRegistry}
import org.mockito.ArgumentMatchers._
import org.mockito.Mockito._
import org.mockito.invocation.InvocationOnMock
import org.scalatestplus.mockito.MockitoSugar
import org.scalatestplus.play._
import org.scalatestplus.play.guice.GuiceOneServerPerSuite
import play.api.Application
import play.api.inject.bind
import play.api.libs.json.Json
import play.api.test.Helpers._

class MeetingRoomControllerSpec extends PlaySpec with MockitoSugar with GMSearchTestApplicationBuilder
  with ControllerHelpers with GuiceOneServerPerSuite with TestValues {
  val portGetter = mock[PortGetter]

  val esRestClient = mock[RestHighLevelClient]

  val injector = app.injector
  val meetingRoomController = injector.instanceOf[MeetingRoomController]

  def getPort = port
  when(portGetter.getPort).thenReturn(getPort)

  override def fakeApplication(): Application = getBuilder.overrides(bind[RestHighLevelClient].toInstance(esRestClient)).
    overrides(bind[AccessTokenHandler].to[TestAccessTokenHandler], bind[PortGetter].toInstance(portGetter)).build

  var searchResponse: SearchResponse = _
  when(esRestClient.searchAsync(any[SearchRequest], any[RequestOptions], any[ActionListener[SearchResponse]])).
    thenAnswer((invocation: InvocationOnMock) => {
      val callback = invocation.getArgument(2).asInstanceOf[(ActionListener[SearchResponse])]
      callback.onResponse(searchResponse)
    })

  "Calling the get method with Meeting Room ID" must {
    "return JSON with meeting room details" in {
      val esResponse = Json.obj(
        "hits" -> Json.obj(
          "hits" -> Json.arr(
            Json.obj(
              "_index" -> "meetingrooms",
              "_id" -> testMeetingRoomId,
              "_source" -> testEsMeetingRoomResponseSource
            )
          )
        )
      )
      searchResponse = SearchResponse.fromXContent(new JsonXContentParser(NamedXContentRegistry.EMPTY,
        DeprecationHandler.THROW_UNSUPPORTED_OPERATION, new JsonFactory().createParser(esResponse.toString())))

      val result = call(meetingRoomController.getMeetingRoom(testMeetingRoomId, Seq.empty, idsOnly = false),
        generateFakeGetRequestWithScope("gmsearch"))
      status(result) mustBe OK
      contentAsJson(result) mustBe testMeetingRoomResponse
    }
    "return JSON with only the Meeting Room ID" in {
      val esResponse = Json.obj(
        "hits" -> Json.obj(
          "hits" -> Json.arr(
            Json.obj(
              "_index" -> "meetingrooms",
              "_id" -> testMeetingRoomId
            )
          )
        )
      )
      searchResponse = SearchResponse.fromXContent(new JsonXContentParser(NamedXContentRegistry.EMPTY,
        DeprecationHandler.THROW_UNSUPPORTED_OPERATION, new JsonFactory().createParser(esResponse.toString())))

      val result = call(meetingRoomController.getMeetingRoom(testMeetingRoomId, Seq.empty, idsOnly = true),
        generateFakeGetRequestWithScope("gmsearch"))
      status(result) mustBe OK
      contentAsJson(result) mustBe testMeetingRoomResponseWithIdsOnly
    }
  }

  "Calling the get method with Meeting Room URL" must {
    "return JSON with meeting room details" in {
      val esResponse = Json.obj(
        "hits" -> Json.obj(
          "hits" -> Json.arr(
            Json.obj(
              "_index" -> "meetingrooms",
              "_id" -> testMeetingRoomId,
              "_source" -> testEsMeetingRoomResponseSource
            )
          )
        )
      )
      searchResponse = SearchResponse.fromXContent(new JsonXContentParser(NamedXContentRegistry.EMPTY,
        DeprecationHandler.THROW_UNSUPPORTED_OPERATION, new JsonFactory().createParser(esResponse.toString())))

      val result = call(meetingRoomController.getMeetingRoomByUrl(testMeetingRoomUrl, idsOnly = false),
        generateFakeGetRequestWithScope("gmsearch"))
      status(result) mustBe OK
      contentAsJson(result) mustBe testMeetingRoomResponse
    }
    "return JSON with only the Meeting Room ID" in {
      val esResponse = Json.obj(
        "hits" -> Json.obj(
          "hits" -> Json.arr(
            Json.obj(
              "_index" -> "meetingrooms",
              "_id" -> testMeetingRoomId
            )
          )
        )
      )
      searchResponse = SearchResponse.fromXContent(new JsonXContentParser(NamedXContentRegistry.EMPTY,
        DeprecationHandler.THROW_UNSUPPORTED_OPERATION, new JsonFactory().createParser(esResponse.toString())))

      val result = call(meetingRoomController.getMeetingRoomByUrl(testMeetingRoomUrl, idsOnly = true),
        generateFakeGetRequestWithScope("gmsearch"))
      status(result) mustBe OK
      contentAsJson(result) mustBe testMeetingRoomResponseWithIdsOnly
    }
  }

  "Calling the get method with unknown Meeting Room ID" must {
    "return not found error" in {
      val esResponse = Json.obj(
        "hits" -> Json.obj(
          "hits" -> Json.arr()
        )
      )
      searchResponse = SearchResponse.fromXContent(new JsonXContentParser(NamedXContentRegistry.EMPTY,
        DeprecationHandler.THROW_UNSUPPORTED_OPERATION, new JsonFactory().createParser(esResponse.toString())))

      val result = call(meetingRoomController.getMeetingRoom(testMeetingRoomId, Seq.empty, idsOnly = false),
        generateFakeGetRequestWithScope("gmsearch"))
      status(result) mustBe NOT_FOUND
    }
  }
}
