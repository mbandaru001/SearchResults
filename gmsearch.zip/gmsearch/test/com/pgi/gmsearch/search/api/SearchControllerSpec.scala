package com.pgi.gmsearch.search.api

import com.fasterxml.jackson.core.JsonFactory
import com.pgi.gmsearch.common.{NameOrders, SearchObjectTypes}
import com.pgi.gmsearch.infrastructure.play.bindables.SearchQueryParam
import com.pgi.gmsearch.search.test.{GMSearchTestApplicationBuilder, TestAccessTokenHandler, TestValues}
import com.pgi.playframework.infrastructure.play.essentialactions.AccessTokenHandler
import com.pgi.playframework.test.{ControllerHelpers, PortGetter}
import org.elasticsearch.action.ActionListener
import org.elasticsearch.action.search.{SearchRequest, SearchResponse}
import org.elasticsearch.client.{RequestOptions, RestHighLevelClient}
import org.elasticsearch.common.xcontent.json.JsonXContentParser
import org.elasticsearch.common.xcontent.{DeprecationHandler, NamedXContentRegistry}
import org.mockito.ArgumentMatchers.{any, _}
import org.mockito.Mockito._
import org.mockito.invocation.InvocationOnMock
import org.scalatestplus.mockito.MockitoSugar
import org.scalatestplus.play._
import org.scalatestplus.play.guice.GuiceOneServerPerSuite
import play.api.Application
import play.api.inject.bind
import play.api.libs.json.Json
import play.api.test.Helpers._

class SearchControllerSpec extends PlaySpec with MockitoSugar with GMSearchTestApplicationBuilder
  with ControllerHelpers with GuiceOneServerPerSuite with TestValues {
  val portGetter = mock[PortGetter]

  val esRestClient = mock[RestHighLevelClient]

  val injector = app.injector
  val searchController = injector.instanceOf[SearchController]

  def getPort = port
  when(portGetter.getPort).thenReturn(getPort)

  override def fakeApplication(): Application = getBuilder.overrides(bind[RestHighLevelClient].toInstance(esRestClient)).
    overrides(bind[AccessTokenHandler].to[TestAccessTokenHandler], bind[PortGetter].toInstance(portGetter)).build

  var searchResponse: SearchResponse = _
  when(esRestClient.searchAsync(any[SearchRequest], any[RequestOptions], any[ActionListener[SearchResponse]])).
    thenAnswer((invocation: InvocationOnMock) => {
      val callback = invocation.getArgument(2).asInstanceOf[(ActionListener[SearchResponse])]
      callback.onResponse(searchResponse)
    })

  "Calling the search method with search criteria for meeting rooms" must {
    "return JSON with meeting room details with no highlighting" in {
      val testSearchResponse = Json.obj(
        "totalCount" -> 1,
        "items" -> Json.arr(Json.obj(
          "id" -> testMeetingRoomId,
          "resourceUri" -> s"/meetingrooms/$testMeetingRoomId",
          "resourceType" -> "MeetingRoom",
          "title" -> testOwnerNameWesternOrder,
          "secondaryTitle" -> testMeetingRoomUrl,
          "externalUrl" -> testMeetingRoomUrl,
          "imageUrl" -> testImageUrl,
          "metadata" -> testMeetingSearchResponseMetadata,
          "inactive" -> false
        ))
      )

      val esResponse = Json.obj(
        "hits" -> Json.obj(
          "total" -> 1,
          "hits" -> Json.arr(
            Json.obj(
              "_index" -> "meetingrooms:x.y.z",
              "_id" -> testMeetingRoomId,
              "_source" -> testEsMeetingRoomResponseSource
            )
          )
        )
      )
      searchResponse = SearchResponse.fromXContent(new JsonXContentParser(NamedXContentRegistry.EMPTY,
        DeprecationHandler.THROW_UNSUPPORTED_OPERATION, new JsonFactory().createParser(esResponse.toString())))

      val searchCriteria = "Jonathan Pea"
      val result = call(searchController.search(searchCriteria, Seq.empty, Seq(SearchObjectTypes.MeetingRoomsIndex), None, Some("any"), 10, 0, idsOnly = false, hl = false),
        generateFakeGetRequestWithScope("gmsearch"))
      status(result) mustBe OK
      contentAsJson(result) mustBe testSearchResponse
    }
    "return JSON with highlighting" in {
      val testSearchResponse = Json.obj(
        "totalCount" -> 1,
        "items" -> Json.arr(Json.obj(
          "id" -> testMeetingRoomId,
          "resourceUri" -> s"/meetingrooms/$testMeetingRoomId",
          "resourceType" -> "MeetingRoom",
          "title" -> s"${PreHlTag}Jonathan Pea${PostHlTag}rson",
          "secondaryTitle" -> testMeetingRoomUrl,
          "externalUrl" -> testMeetingRoomUrl,
          "imageUrl" -> testImageUrl,
          "metadata" -> testMeetingSearchResponseMetadata,
          "inactive" -> false
        ))
      )

      val esResponse = Json.obj(
        "hits" -> Json.obj(
          "total" -> 1,
          "hits" -> Json.arr(
            Json.obj(
              "_index" -> "meetingrooms",
              "_id" -> testMeetingRoomId,
              "_source" -> testEsMeetingRoomResponseSource,
              "highlight" -> Json.obj(
                "ownerName_westernOrder.autocompleteWs" -> Json.arr(s"${PreHlTag}Jonathan Pea${PostHlTag}rson"),
                "ownerName_westernOrder.autocomplete" -> Json.arr(s"${PreHlTag}Jonathan Pea${PostHlTag}rson"),
                "ownerFamilyName.autocomplete" -> Json.arr(s"${PreHlTag}Pea${PostHlTag}rson")
              )
            )
          )
        )
      )
      searchResponse = SearchResponse.fromXContent(new JsonXContentParser(NamedXContentRegistry.EMPTY,
        DeprecationHandler.THROW_UNSUPPORTED_OPERATION, new JsonFactory().createParser(esResponse.toString())))

      val searchCriteria = "Jonathan Pea"
      val result = call(searchController.search(searchCriteria, Seq.empty, Seq(SearchObjectTypes.MeetingRoomsIndex), None, Some("any"), 10, 0, idsOnly = false, hl = false),
        generateFakeGetRequestWithScope("gmsearch"))
      status(result) mustBe OK
      contentAsJson(result) mustBe testSearchResponse
    }
    "return JSON with multiple highlights" in {
      val testSearchResponse = Json.obj(
        "totalCount" -> 1,
        "items" -> Json.arr(Json.obj(
          "id" -> testMeetingRoomId,
          "resourceUri" -> s"/meetingrooms/$testMeetingRoomId",
          "resourceType" -> "MeetingRoom",
          "title" -> s"${PreHlTag}Jonath${PostHlTag}an Pearson",
          "secondaryTitle" -> s"https://myglobalmeet.itdev.local/${PreHlTag}Jonath${PostHlTag}anDev",
          "externalUrl" -> testMeetingRoomUrl,
          "imageUrl" -> testImageUrl,
          "metadata" -> testMeetingSearchResponseMetadata,
          "inactive" -> false
        ))
      )

      val esResponse = Json.obj(
        "hits" -> Json.obj(
          "total" -> 1,
          "hits" -> Json.arr(
            Json.obj(
              "_index" -> "meetingrooms:x.y.z",
              "_id" -> testMeetingRoomId,
              "_source" -> testEsMeetingRoomResponseSource,
              "highlight" -> Json.obj(
                "ownerName_westernOrder.autocompleteWs" -> Json.arr(s"${PreHlTag}Jonath${PostHlTag}an Pearson"),
                "ownerName_westernOrder.autocomplete" -> Json.arr(s"${PreHlTag}Jonath${PostHlTag}an Pearson"),
                "meetingRoomUrlRoomName.autocomplete" -> Json.arr(s"${PreHlTag}Jonath${PostHlTag}anDev")
              )
            )
          )
        )
      )
      searchResponse = SearchResponse.fromXContent(new JsonXContentParser(NamedXContentRegistry.EMPTY,
        DeprecationHandler.THROW_UNSUPPORTED_OPERATION, new JsonFactory().createParser(esResponse.toString())))

      val searchCriteria = "Jonath"
      val result = call(searchController.search(searchCriteria, Seq.empty, Seq(SearchObjectTypes.MeetingRoomsIndex), None, Some("any"), 10, 0, idsOnly = false, hl = false),
        generateFakeGetRequestWithScope("gmsearch"))
      status(result) mustBe OK
      contentAsJson(result) mustBe testSearchResponse
    }
    "return JSON with meeting room details in western name order" in {
      val testSearchResponse = Json.obj(
        "totalCount" -> 1,
        "items" -> Json.arr(Json.obj(
          "id" -> testMeetingRoomId,
          "resourceUri" -> s"/meetingrooms/$testMeetingRoomId",
          "resourceType" -> "MeetingRoom",
          "title" -> testOwnerNameWesternOrder,
          "secondaryTitle" -> testMeetingRoomUrl,
          "externalUrl" -> testMeetingRoomUrl,
          "imageUrl" -> testImageUrl,
          "metadata" -> testMeetingSearchResponseMetadata,
          "inactive" -> false
        ))
      )

      val esResponse = Json.obj(
        "hits" -> Json.obj(
          "total" -> 1,
          "hits" -> Json.arr(
            Json.obj(
              "_index" -> "meetingrooms",
              "_id" -> testMeetingRoomId,
              "_source" -> testEsMeetingRoomResponseSource
            )
          )
        )
      )
      searchResponse = SearchResponse.fromXContent(new JsonXContentParser(NamedXContentRegistry.EMPTY,
        DeprecationHandler.THROW_UNSUPPORTED_OPERATION, new JsonFactory().createParser(esResponse.toString())))

      val searchCriteria = "Jonathan Pea"
      val result = call(searchController.search(searchCriteria, Seq.empty, Seq(SearchObjectTypes.MeetingRoomsIndex), Some(NameOrders.WesternOrder), Some("any"), 10, 0, idsOnly = false, hl = false),
        generateFakeGetRequestWithScope("gmsearch"))
      status(result) mustBe OK
      contentAsJson(result) mustBe testSearchResponse
    }
    "return JSON with meeting room details in eastern name order" in {
      val testSearchResponse = Json.obj(
        "totalCount" -> 1,
        "items" -> Json.arr(Json.obj(
          "id" -> testMeetingRoomId,
          "resourceUri" -> s"/meetingrooms/$testMeetingRoomId",
          "resourceType" -> "MeetingRoom",
          "title" -> testOwnerNameEasternOrder,
          "secondaryTitle" -> testMeetingRoomUrl,
          "externalUrl" -> testMeetingRoomUrl,
          "imageUrl" -> testImageUrl,
          "metadata" -> testMeetingSearchResponseMetadata,
          "inactive" -> false
        ))
      )

      val esResponse = Json.obj(
        "hits" -> Json.obj(
          "total" -> 1,
          "hits" -> Json.arr(
            Json.obj(
              "_index" -> "meetingrooms:x.y.z",
              "_id" -> testMeetingRoomId,
              "_source" -> testEsMeetingRoomResponseSource
            )
          )
        )
      )
      searchResponse = SearchResponse.fromXContent(new JsonXContentParser(NamedXContentRegistry.EMPTY,
        DeprecationHandler.THROW_UNSUPPORTED_OPERATION, new JsonFactory().createParser(esResponse.toString())))

      val searchCriteria = "Jonathan Pea"
      val result = call(searchController.search(searchCriteria, Seq.empty, Seq(SearchObjectTypes.MeetingRoomsIndex), Some(NameOrders.EasternOrder), Some("any"), 10, 0, idsOnly = false, hl = false),
        generateFakeGetRequestWithScope("gmsearch"))
      status(result) mustBe OK
      contentAsJson(result) mustBe testSearchResponse
    }
  }

  "Calling the search method with search criteria for contacts" must {
    "return JSON with contact details with no highlighting" in {
      val testSearchResponse = Json.obj(
        "totalCount" -> 1,
        "items" -> Json.arr(Json.obj(
          "id" -> testClientId,
          "resourceUri" -> s"/contacts/$testClientId",
          "resourceType" -> "Contact",
          "title" -> testOwnerNameWesternOrder,
          "secondaryTitle" -> testOwnerEmail,
          "imageUrl" -> testImageUrl,
          "metadata" -> testContactSearchResponseMetadata,
          "inactive" -> false
        ))
      )

      val esResponse = Json.obj(
        "hits" -> Json.obj(
          "total" -> 1,
          "hits" -> Json.arr(
            Json.obj(
              "_index" -> "contacts:x.y.z",
              "_id" -> testClientId,
              "_source" -> testEsContactResponseSource
            )
          )
        )
      )
      searchResponse = SearchResponse.fromXContent(new JsonXContentParser(NamedXContentRegistry.EMPTY,
        DeprecationHandler.THROW_UNSUPPORTED_OPERATION, new JsonFactory().createParser(esResponse.toString())))

      val searchCriteria = "Jonathan Pea"
      val result = call(searchController.search(searchCriteria, Seq.empty, Seq(SearchObjectTypes.MeetingRoomsIndex), None, Some("any"), 10, 0, idsOnly = false, hl = false),
        generateFakeGetRequestWithScope("gmsearch"))
      status(result) mustBe OK
      contentAsJson(result) mustBe testSearchResponse
    }
    "return JSON with highlighting" in {
      val testSearchResponse = Json.obj(
        "totalCount" -> 1,
        "items" -> Json.arr(Json.obj(
          "id" -> testClientId,
          "resourceUri" -> s"/contacts/$testClientId",
          "resourceType" -> "Contact",
          "title" -> s"${PreHlTag}Jonathan Pea${PostHlTag}rson",
          "secondaryTitle" -> testOwnerEmail,
          "imageUrl" -> testImageUrl,
          "metadata" -> testContactSearchResponseMetadata,
          "inactive" -> false
        ))
      )

      val esResponse = Json.obj(
        "hits" -> Json.obj(
          "total" -> 1,
          "hits" -> Json.arr(
            Json.obj(
              "_index" -> "contacts",
              "_id" -> testClientId,
              "_source" -> testEsContactResponseSource,
              "highlight" -> Json.obj(
                "ownerName_westernOrder.autocompleteWs" -> Json.arr(s"${PreHlTag}Jonathan Pea${PostHlTag}rson"),
                "ownerName_westernOrder.autocomplete" -> Json.arr(s"${PreHlTag}Jonathan Pea${PostHlTag}rson"),
                "ownerFamilyName.autocomplete" -> Json.arr(s"${PreHlTag}Pea${PostHlTag}rson")
              )
            )
          )
        )
      )
      searchResponse = SearchResponse.fromXContent(new JsonXContentParser(NamedXContentRegistry.EMPTY,
        DeprecationHandler.THROW_UNSUPPORTED_OPERATION, new JsonFactory().createParser(esResponse.toString())))

      val searchCriteria = "Jonathan Pea"
      val result = call(searchController.search(searchCriteria, Seq.empty, Seq(SearchObjectTypes.MeetingRoomsIndex), None, Some("any"), 10, 0, idsOnly = false, hl = false),
        generateFakeGetRequestWithScope("gmsearch"))
      status(result) mustBe OK
      contentAsJson(result) mustBe testSearchResponse
    }
    "return JSON with multiple highlights" in {
      val testSearchResponse = Json.obj(
        "totalCount" -> 1,
        "items" -> Json.arr(Json.obj(
          "id" -> testClientId,
          "resourceUri" -> s"/contacts/$testClientId",
          "resourceType" -> "Contact",
          "title" -> s"${PreHlTag}Jonath${PostHlTag}an Pearson",
          "secondaryTitle" -> s"${PreHlTag}jonath${PostHlTag}an.pearson@pgi.com",
          "imageUrl" -> testImageUrl,
          "metadata" -> testContactSearchResponseMetadata,
          "inactive" -> false
        ))
      )

      val esResponse = Json.obj(
        "hits" -> Json.obj(
          "total" -> 1,
          "hits" -> Json.arr(
            Json.obj(
              "_index" -> "contacts:x.y.z",
              "_id" -> testClientId,
              "_source" -> testEsContactResponseSource,
              "highlight" -> Json.obj(
                "ownerName_westernOrder.autocompleteWs" -> Json.arr(s"${PreHlTag}Jonath${PostHlTag}an Pearson"),
                "ownerName_westernOrder.autocomplete" -> Json.arr(s"${PreHlTag}Jonath${PostHlTag}an Pearson"),
                "ownerEmail.autocomplete" -> Json.arr(s"${PreHlTag}jonath${PostHlTag}an.pearson@pgi.com")
              )
            )
          )
        )
      )
      searchResponse = SearchResponse.fromXContent(new JsonXContentParser(NamedXContentRegistry.EMPTY,
        DeprecationHandler.THROW_UNSUPPORTED_OPERATION, new JsonFactory().createParser(esResponse.toString())))

      val searchCriteria = "jonath"
      val result = call(searchController.search(searchCriteria, Seq.empty, Seq(SearchObjectTypes.MeetingRoomsIndex), None, Some("any"), 10, 0, idsOnly = false, hl = false),
        generateFakeGetRequestWithScope("gmsearch"))
      status(result) mustBe OK
      contentAsJson(result) mustBe testSearchResponse
    }
    "return JSON with contact details in western name order" in {
      val testSearchResponse = Json.obj(
        "totalCount" -> 1,
        "items" -> Json.arr(Json.obj(
          "id" -> testClientId,
          "resourceUri" -> s"/contacts/$testClientId",
          "resourceType" -> "Contact",
          "title" -> testOwnerNameWesternOrder,
          "secondaryTitle" -> testOwnerEmail,
          "imageUrl" -> testImageUrl,
          "metadata" -> testContactSearchResponseMetadata,
          "inactive" -> false
        ))
      )

      val esResponse = Json.obj(
        "hits" -> Json.obj(
          "total" -> 1,
          "hits" -> Json.arr(
            Json.obj(
              "_index" -> "contacts",
              "_id" -> testClientId,
              "_source" -> testEsContactResponseSource
            )
          )
        )
      )
      searchResponse = SearchResponse.fromXContent(new JsonXContentParser(NamedXContentRegistry.EMPTY,
        DeprecationHandler.THROW_UNSUPPORTED_OPERATION, new JsonFactory().createParser(esResponse.toString())))

      val searchCriteria = "Jonathan Pea"
      val result = call(searchController.search(searchCriteria, Seq.empty, Seq(SearchObjectTypes.MeetingRoomsIndex), Some(NameOrders.WesternOrder), Some("any"), 10, 0, idsOnly = false, hl = false),
        generateFakeGetRequestWithScope("gmsearch"))
      status(result) mustBe OK
      contentAsJson(result) mustBe testSearchResponse
    }
    "return JSON with contact details in eastern name order" in {
      val testSearchResponse = Json.obj(
        "totalCount" -> 1,
        "items" -> Json.arr(Json.obj(
          "id" -> testClientId,
          "resourceUri" -> s"/contacts/$testClientId",
          "resourceType" -> "Contact",
          "title" -> testOwnerNameEasternOrder,
          "secondaryTitle" -> testOwnerEmail,
          "imageUrl" -> testImageUrl,
          "metadata" -> testContactSearchResponseMetadata,
          "inactive" -> false
        ))
      )

      val esResponse = Json.obj(
        "hits" -> Json.obj(
          "total" -> 1,
          "hits" -> Json.arr(
            Json.obj(
              "_index" -> "contacts:x.y.z",
              "_id" -> testClientId,
              "_source" -> testEsContactResponseSource
            )
          )
        )
      )
      searchResponse = SearchResponse.fromXContent(new JsonXContentParser(NamedXContentRegistry.EMPTY,
        DeprecationHandler.THROW_UNSUPPORTED_OPERATION, new JsonFactory().createParser(esResponse.toString())))

      val searchCriteria = "Jonathan Pea"
      val result = call(searchController.search(searchCriteria, Seq.empty, Seq(SearchObjectTypes.MeetingRoomsIndex), Some(NameOrders.EasternOrder), Some("any"), 10, 0, idsOnly = false, hl = false),
        generateFakeGetRequestWithScope("gmsearch"))
      status(result) mustBe OK
      contentAsJson(result) mustBe testSearchResponse
    }
  }

  "Calling the search method with search criteria for more than one type" must {
    "return JSON with type's details" in {
      val esResponse = Json.obj(
        "hits" -> Json.obj(
          "total" -> 2,
          "hits" -> Json.arr(
            Json.obj(
              "_index" -> "meetingrooms:x.y.z",
              "_id" -> testMeetingRoomId,
              "_source" -> testEsMeetingRoomResponseSource
            ),
            Json.obj(
              "_index" -> "contacts",
              "_id" -> testClientId,
              "_source" -> testEsContactResponseSource
            )
          )
        )
      )
      searchResponse = SearchResponse.fromXContent(new JsonXContentParser(NamedXContentRegistry.EMPTY,
        DeprecationHandler.THROW_UNSUPPORTED_OPERATION, new JsonFactory().createParser(esResponse.toString())))

      val searchCriteria = "jonathan.pearson@pgi.com"
      val result = call(searchController.search(searchCriteria, Seq.empty, Seq(SearchObjectTypes.MeetingRoomsIndex, SearchObjectTypes.ContactsIndex),
        None, Some("any"), 10, 0, idsOnly = false, hl = false),
        generateFakeGetRequestWithScope("gmsearch"))
      status(result) mustBe OK
      contentAsJson(result) mustBe testSearchResponseListWesternOrder
    }
  }

  "Calling the search method with search criteria for more than one type" must {
    "return JSON with type's details with no highlighting" in {
      val testSearchResponse = Json.obj(
        "totalCount" -> 2,
        "items" -> Json.arr(
          Json.obj(
            "id" -> testMeetingRoomId,
            "resourceUri" -> s"/meetingrooms/$testMeetingRoomId",
            "resourceType" -> "MeetingRoom",
            "title" -> testOwnerNameWesternOrder,
            "secondaryTitle" -> testMeetingRoomUrl,
            "externalUrl" -> testMeetingRoomUrl,
            "imageUrl" -> testImageUrl,
            "metadata" -> testMeetingSearchResponseMetadata,
            "inactive" -> false
          ),
          Json.obj(
            "id" -> testClientId,
            "resourceUri" -> s"/contacts/$testClientId",
            "resourceType" -> "Contact",
            "title" -> testOwnerNameWesternOrder,
            "secondaryTitle" -> testOwnerEmail,
            "imageUrl" -> testImageUrl,
            "metadata" -> testContactSearchResponseMetadata,
            "inactive" -> false
          )
        )
      )

      val esResponse = Json.obj(
        "hits" -> Json.obj(
          "total" -> 2,
          "hits" -> Json.arr(
            Json.obj(
              "_index" -> "meetingrooms",
              "_id" -> testMeetingRoomId,
              "_source" -> testEsMeetingRoomResponseSource
            ),
            Json.obj(
              "_index" -> "contacts:x.y.z",
              "_id" -> testClientId,
              "_source" -> testEsContactResponseSource
            )
          )
        )
      )
      searchResponse = SearchResponse.fromXContent(new JsonXContentParser(NamedXContentRegistry.EMPTY,
        DeprecationHandler.THROW_UNSUPPORTED_OPERATION, new JsonFactory().createParser(esResponse.toString())))

      val searchCriteria = "Jonathan Pea"
      val result = call(searchController.search(searchCriteria, Seq.empty, Seq(SearchObjectTypes.MeetingRoomsIndex), None, Some("any"), 10, 0, idsOnly = false, hl = false),
        generateFakeGetRequestWithScope("gmsearch"))
      status(result) mustBe OK
      contentAsJson(result) mustBe testSearchResponse
    }
    "return JSON with highlighting" in {
      val testSearchResponse = Json.obj(
        "totalCount" -> 2,
        "items" -> Json.arr(
          Json.obj(
            "id" -> testMeetingRoomId,
            "resourceUri" -> s"/meetingrooms/$testMeetingRoomId",
            "resourceType" -> "MeetingRoom",
            "title" -> s"${PreHlTag}Jonathan Pea${PostHlTag}rson",
            "secondaryTitle" -> testMeetingRoomUrl,
            "externalUrl" -> testMeetingRoomUrl,
            "imageUrl" -> testImageUrl,
            "metadata" -> testMeetingSearchResponseMetadata,
            "inactive" -> false
          ),
          Json.obj(
            "id" -> testClientId,
            "resourceUri" -> s"/contacts/$testClientId",
            "resourceType" -> "Contact",
            "title" -> s"${PreHlTag}Jonathan Pea${PostHlTag}rson",
            "secondaryTitle" -> testOwnerEmail,
            "imageUrl" -> testImageUrl,
            "metadata" -> testContactSearchResponseMetadata,
            "inactive" -> false
          )
        )
      )

      val esResponse = Json.obj(
        "hits" -> Json.obj(
          "total" -> 2,
          "hits" -> Json.arr(
            Json.obj(
              "_index" -> "meetingrooms",
              "_id" -> testMeetingRoomId,
              "_source" -> testEsMeetingRoomResponseSource,
              "highlight" -> Json.obj(
                "ownerName_westernOrder.autocompleteWs" -> Json.arr(s"${PreHlTag}Jonathan Pea${PostHlTag}rson"),
                "ownerName_westernOrder.autocomplete" -> Json.arr(s"${PreHlTag}Jonathan Pea${PostHlTag}rson"),
                "ownerFamilyName.autocomplete" -> Json.arr(s"${PreHlTag}Pea${PostHlTag}rson")
              )
            ),
            Json.obj(
              "_index" -> "contacts",
              "_id" -> testClientId,
              "_source" -> testEsContactResponseSource,
              "highlight" -> Json.obj(
                "ownerName_westernOrder.autocompleteWs" -> Json.arr(s"${PreHlTag}Jonathan Pea${PostHlTag}rson"),
                "ownerName_westernOrder.autocomplete" -> Json.arr(s"${PreHlTag}Jonathan Pea${PostHlTag}rson"),
                "ownerFamilyName.autocomplete" -> Json.arr(s"${PreHlTag}Pea${PostHlTag}rson")
              )
            )
          )
        )
      )
      searchResponse = SearchResponse.fromXContent(new JsonXContentParser(NamedXContentRegistry.EMPTY,
        DeprecationHandler.THROW_UNSUPPORTED_OPERATION, new JsonFactory().createParser(esResponse.toString())))

      val searchCriteria = "Jonathan Pea"
      val result = call(searchController.search(searchCriteria, Seq.empty, Seq(SearchObjectTypes.MeetingRoomsIndex), None, Some("any"), 10, 0, idsOnly = false, hl = false),
        generateFakeGetRequestWithScope("gmsearch"))
      status(result) mustBe OK
      contentAsJson(result) mustBe testSearchResponse
    }
    "return active records in JSON when inactive=false is passed in qparam" in {
      val testSearchResponse = Json.obj(
        "totalCount" -> 2,
        "items" -> Json.arr(
          Json.obj(
            "id" -> testMeetingRoomId,
            "resourceUri" -> s"/meetingrooms/$testMeetingRoomId",
            "resourceType" -> "MeetingRoom",
            "title" -> s"${PreHlTag}Jonathan Pea${PostHlTag}rson",
            "secondaryTitle" -> testMeetingRoomUrl,
            "externalUrl" -> testMeetingRoomUrl,
            "imageUrl" -> testImageUrl,
            "inactive" -> false,
            "metadata" -> testMeetingSearchResponseMetadata
          ),
          Json.obj(
            "id" -> testClientId,
            "resourceUri" -> s"/contacts/$testClientId",
            "resourceType" -> "Contact",
            "title" -> s"${PreHlTag}Jonathan Pea${PostHlTag}rson",
            "secondaryTitle" -> testOwnerEmail,
            "imageUrl" -> testImageUrl,
            "inactive" -> false,
            "metadata" -> testContactSearchResponseMetadata
          )
        )
      )

      val esResponse = Json.obj(
        "hits" -> Json.obj(
          "total" -> 2,
          "hits" -> Json.arr(
            Json.obj(
              "_index" -> "meetingrooms",
              "_id" -> testMeetingRoomId,
              "_source" -> testEsMeetingRoomResponseSource,
              "highlight" -> Json.obj(
                "ownerName_westernOrder.autocompleteWs" -> Json.arr(s"${PreHlTag}Jonathan Pea${PostHlTag}rson"),
                "ownerName_westernOrder.autocomplete" -> Json.arr(s"${PreHlTag}Jonathan Pea${PostHlTag}rson"),
                "ownerFamilyName.autocomplete" -> Json.arr(s"${PreHlTag}Pea${PostHlTag}rson")
              )
            ),
            Json.obj(
              "_index" -> "contacts",
              "_id" -> testClientId,
              "_source" -> testEsContactResponseSource,
              "highlight" -> Json.obj(
                "ownerName_westernOrder.autocompleteWs" -> Json.arr(s"${PreHlTag}Jonathan Pea${PostHlTag}rson"),
                "ownerName_westernOrder.autocomplete" -> Json.arr(s"${PreHlTag}Jonathan Pea${PostHlTag}rson"),
                "ownerFamilyName.autocomplete" -> Json.arr(s"${PreHlTag}Pea${PostHlTag}rson")
              )
            )
          )
        )
      )
      searchResponse = SearchResponse.fromXContent(new JsonXContentParser(NamedXContentRegistry.EMPTY,
        DeprecationHandler.THROW_UNSUPPORTED_OPERATION, new JsonFactory().createParser(esResponse.toString())))

      val searchCriteria = "Jonathan Pea"
      val result = call(searchController.search(searchCriteria, Seq.empty, Seq(SearchObjectTypes.MeetingRoomsIndex), None, Some("false"), 10, 0, idsOnly = false, hl = false),
        generateFakeGetRequestWithScope("gmsearch"))
      status(result) mustBe OK
      contentAsJson(result) mustBe testSearchResponse
    }
    "return inactive records in JSON when inactive=true is passed in qparam" in {
      val testSearchResponse = Json.obj(
        "totalCount" -> 2,
        "items" -> Json.arr(
          Json.obj(
            "id" -> testMeetingRoomId,
            "resourceUri" -> s"/meetingrooms/$testMeetingRoomId",
            "resourceType" -> "MeetingRoom",
            "title" -> s"${PreHlTag}Jonathan Pea${PostHlTag}rson",
            "secondaryTitle" -> testMeetingRoomUrl,
            "externalUrl" -> testMeetingRoomUrl,
            "imageUrl" -> testImageUrl,
            "inactive" -> true,
            "metadata" -> testMeetingSearchResponseMetadata
          ),
          Json.obj(
            "id" -> testClientId,
            "resourceUri" -> s"/contacts/$testClientId",
            "resourceType" -> "Contact",
            "title" -> s"${PreHlTag}Jonathan Pea${PostHlTag}rson",
            "secondaryTitle" -> testOwnerEmail,
            "imageUrl" -> testImageUrl,
            "inactive" -> true,
            "metadata" -> testContactSearchResponseMetadata
          )
        )
      )

      val esResponse = Json.obj(
        "hits" -> Json.obj(
          "total" -> 2,
          "hits" -> Json.arr(
            Json.obj(
              "_index" -> "meetingrooms",
              "_id" -> testMeetingRoomId,
              "_source" -> testInactiveEsMeetingRoomResponseSource,
              "highlight" -> Json.obj(
                "ownerName_westernOrder.autocompleteWs" -> Json.arr(s"${PreHlTag}Jonathan Pea${PostHlTag}rson"),
                "ownerName_westernOrder.autocomplete" -> Json.arr(s"${PreHlTag}Jonathan Pea${PostHlTag}rson"),
                "ownerFamilyName.autocomplete" -> Json.arr(s"${PreHlTag}Pea${PostHlTag}rson")
              )
            ),
            Json.obj(
              "_index" -> "contacts",
              "_id" -> testClientId,
              "_source" -> testInactiveEsContactResponseSource,
              "highlight" -> Json.obj(
                "ownerName_westernOrder.autocompleteWs" -> Json.arr(s"${PreHlTag}Jonathan Pea${PostHlTag}rson"),
                "ownerName_westernOrder.autocomplete" -> Json.arr(s"${PreHlTag}Jonathan Pea${PostHlTag}rson"),
                "ownerFamilyName.autocomplete" -> Json.arr(s"${PreHlTag}Pea${PostHlTag}rson")
              )
            )
          )
        )
      )
      searchResponse = SearchResponse.fromXContent(new JsonXContentParser(NamedXContentRegistry.EMPTY,
        DeprecationHandler.THROW_UNSUPPORTED_OPERATION, new JsonFactory().createParser(esResponse.toString())))

      val searchCriteria = "Jonathan Pea"
      val result = call(searchController.search(searchCriteria, Seq.empty, Seq(SearchObjectTypes.MeetingRoomsIndex), None, Some("true"), 10, 0, idsOnly = false, hl = false),
        generateFakeGetRequestWithScope("gmsearch"))
      status(result) mustBe OK
      contentAsJson(result) mustBe testSearchResponse
    }
  }

  "Calling the suggest method" must {
    "return JSON array" in {
      val esResponse = Json.obj(
        "hits" -> Json.obj(
          "total" -> 2,
          "hits" -> Json.arr(
            Json.obj(
              "_index" -> "meetingrooms:x.y.z",
              "_id" -> testMeetingRoomId,
              "_source" -> testEsMeetingRoomResponseSource
            ),
            Json.obj(
              "_index" -> "contacts",
              "_id" -> testClientId,
              "_source" -> testEsContactResponseSource
            )
          )
        )
      )
      searchResponse = SearchResponse.fromXContent(new JsonXContentParser(NamedXContentRegistry.EMPTY,
        DeprecationHandler.THROW_UNSUPPORTED_OPERATION, new JsonFactory().createParser(esResponse.toString())))

      val searchCriteria = "jonathan.pearson@pgi.com"
      val result = call(searchController.suggest(searchCriteria, Seq.empty, Seq(SearchObjectTypes.MeetingRoomsIndex, SearchObjectTypes.ContactsIndex),
        None, Some("any"), 10, 0, idsOnly = false, hl = false),
        generateFakeGetRequestWithScope("gmsearch"))
      status(result) mustBe OK
      contentAsJson(result) mustBe testSuggestResponseListWesternOrder
    }
  }
}
