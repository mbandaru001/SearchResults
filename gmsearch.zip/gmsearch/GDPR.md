GMSearch is a general-purpose search engine. Currently, it facilitates searching for meeting rooms. It will eventually faciitate searching for contacts and possibly other elements as well.

All search data is stored in ElasticSearch running as an Amazon service. This data enters ElasticSearch through either DynamoDb events (insert, update, delete) or through a backfill process that reads through the entire DynamoDb table and looks for meeting rooms.

When a user is deactivated or their meeting room is deleted, the meeting room information is deleted from Elastic Search. If all of a host's meeting rooms have been deleted from Elastic Search, then the host will not have any information stored in ElasticSearch.

<table border="" style="border-collapse:collapse" >
   <tbody>
      <tr>
         <th>Personal Data Category</th>
         <th>Types of Personal Data</th>
         <th>Purpose of Processing</th>
         <th>Data Storage</th>
      </tr>
      <tr>
         <td>
            Host Information
         </td>
         <td>
            <ul>
               <li>Host name
               <li>Host email address
               <li>Avatar URL
               <li>Friendly URL (FURL)
               <li>Host's Meeting room name
            </ul>
         </td>
         <td>
            We use Host Information to:<p>
            <ul>
               <li>Allow a participant to search for a meeting room based on the host's email address.
               <li>Allow a participant to search for a meeting room based on the host's first name or last name.
               <li>Display the host's name in the search results.
               <li>Display the host's avatar in the search results.
               <li>Display the host's meeting room name in the search results.
               <li>Allow some back-end PGi services to fetch a minimal set of meeting room information by Meeting Room ID (e.g. fetching the FURL by client ID so that a meeting room may be joined by an automated process).
            </ul>
         </td>
         <td>
            <ul>
                <li>This data is consumed from Amazon DynamoDb, which is restriced by Amazon credentials and roles.
                <li>The indexed data is then stored in ElasticSearch as an Amazon service. This is also restricted by Amazon credentials and roles.
            </ul> 
         </td>
      </tr>
   </tbody>
</table>
