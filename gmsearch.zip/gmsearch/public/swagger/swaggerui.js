window.onload = function() {

    // var accessToken = document.getElementById('accessToken').value;
    var swaggerUrl = document.getElementById('swaggerUrl').value;
    var openAPIJson;

    // this is a semi hack since swagger doesn't seem to support security
    // and securityDefinitions annotations.
    // First get the normally denerated swagger.json
    // then add security and securityDefinitions elements to API Spec.
    // Send SwaggerUIBundle the modified json object.

    /**
     * from swagger-play2 documentation for @SwaggerDefinition

     * Annotation that configures definition level metadata. Still missing are the following:
     * - Security Definitions
     * - Security Requirements
     * - Parameters
     * - Responses
     *
     * @since 1.5.0
     */

    getOpenAPIJSON(swaggerUrl, function(openAPIJson) {

        openAPIJson.securityDefinitions = {
            Bearer: {
                type: "apiKey",
                name: "Authorization",
                in: "header"
            }
        };

        openAPIJson.security = [ { "Bearer": [] } ];

        var ui = SwaggerUIBundle({
            spec: openAPIJson,
            dom_id: '#swagger-ui',
            validatorUrl: null,
            docExpansion: 'none',
            presets: [
                SwaggerUIBundle.presets.apis,
                SwaggerUIStandalonePreset
            ],
            plugins: [
                SwaggerUIBundle.plugins.DownloadUrl
            ]
        });

        // authorizeBearerToken = {
        //     "Bearer": {
        //         "name": "Bearer",
        //         "schema": {
        //             "type": "apiKey",
        //             "in": "header",
        //             "name": "Authorization",
        //             "description": ""},
        //         "value": "Bearer " + accessToken
        //     }
        // };

        // fake the authorizing the Bearer Token
        // ui.authActions.authorize(authorizeBearerToken);

        window.ui = ui;

    });

    function getOpenAPIJSON (url, callback) {
        var xhr = new XMLHttpRequest();
        xhr.open('GET', url, true);
        xhr.responseType = 'json';
        xhr.onload = function() {
            var status = xhr.status;
            if (status == 200) {
                var response = xhr.response;
                if( typeof response === "string" ) {
                    response = JSON.parse(response);
                }
                callback(response);
            } else {
                alert(status);
            }
        };
        xhr.send();
    };

};
