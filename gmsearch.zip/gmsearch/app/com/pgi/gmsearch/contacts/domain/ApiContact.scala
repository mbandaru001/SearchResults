package com.pgi.gmsearch.contacts.domain

import ai.x.play.json.Jsonx
import com.pgi.gmsearch.contacts.api.routes
import com.pgi.playframework.domain.ApiObject
import io.swagger.annotations.{ApiModel, ApiModelProperty}

import scala.annotation.meta.field

object ApiContact {
  final val ResourceType = "Contact"

  implicit lazy val contactFormat = Jsonx.formatCaseClass[ApiContact]

  def getContactUrl(contactId: String): String = routes.ContactsController.getContact(contactId, Seq.empty).url

  def apply(id: String, details: Option[ApiContactDetails]): ApiContact = ApiContact(id, getContactUrl(id), details = details)
}

@ApiModel(value = "Contact")
case class ApiContact(
    @(ApiModelProperty@field)(position = 1, required = true)
    id: String,

    @(ApiModelProperty @field)(position = 2, required = true)
    resourceUri: String,

    @(ApiModelProperty@field)(position = 3, required = true)
    resourceType: String = ApiContact.ResourceType,

    @(ApiModelProperty@field)(position = 4, required = false)
    details: Option[ApiContactDetails] = None
) extends ApiObject
