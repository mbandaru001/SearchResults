package com.pgi.gmsearch.contacts.domain

import com.pgi.gmsearch.common.JsValueWithId
import com.pgi.gmsearch.common.domain._
import com.pgi.gmsearch.common.errors.ElasticSearchResultException
import com.pgi.playframework.infrastructure.play.PlayLogging
import play.api.libs.functional.syntax._
import play.api.libs.json.{Reads, _}

import scala.language.implicitConversions


trait ApiContactConversions extends ApiConversions with PlayLogging {

  implicit def convertToContact(result: JsValueWithId): ApiContact = {
    def contactReads(id: String): Reads[ApiContact] = (
      Reads.pure(id) and
        (
          (__ \ "ownerGivenName").readNullable[String] and
            (__ \ "ownerFamilyName").readNullable[String] and
            (__ \ "ownerEmail").read[String] and
            (__ \ "jobTitle").readNullable[String] and
            (__ \ "profileImageUrls").read[Seq[Image]] and
            (__ \ "phones").readNullable[Seq[Phone]].map(_.getOrElse(Seq.empty)) and
            (__ \ "address").readNullable[Address] and
            (__ \ "meetingRooms").readNullable[Seq[MeetingRoom]].map(_.getOrElse(Seq.empty)) and
            (__ \ "appInfo").readNullable[Map[String, List[JsValue]]]
          ) (ApiContactDetails.apply _).map(Some(_))
      ) (ApiContact.apply(_: String, _: Option[ApiContactDetails]))

    result.json match {
      case Some(json) =>
        implicit val jsonContactReader: Reads[ApiContact] = contactReads(result.id)
        json.validate[ApiContact] match {
          case JsSuccess(contact, _) => contact
          case JsError(ex) => ex.flatMap(e => e._2.map(e._1 -> _)).foreach { error =>
            logger.info(s"Error parsing ${error._1.toString}: ${error._2.message}")
          }
            throw ElasticSearchResultException(s"Could not parse JSON from ElasticSearch: ${json.toString}")
        }
      case _ => ApiContact(result.id, None)
    }
  }

}
