package com.pgi.gmsearch.contacts.domain

import ai.x.play.json.Jsonx
import com.pgi.gmsearch.common.domain.{Address, Image, MeetingRoom, Phone}
import io.swagger.annotations.{ApiModel, ApiModelProperty}
import play.api.libs.json.JsValue

import scala.annotation.meta.field

object ApiContactDetails {
  implicit lazy val contactDetailsFormat = Jsonx.formatCaseClassUseDefaults[ApiContactDetails]
}

@ApiModel(value = "ContactDetails")
case class ApiContactDetails(
    @(ApiModelProperty@field)(position = 1, required = true)
    givenName: Option[String] = None,

    @(ApiModelProperty@field)(position = 2, required = true)
    familyName: Option[String] = None,

    @(ApiModelProperty@field)(position = 3, required = true)
    email: String,

    @(ApiModelProperty@field)(position = 4, required = true)
    jobTitle: Option[String] = None,

    @(ApiModelProperty@field)(position = 5, required = true)
    images: Seq[Image] = Seq.empty,

    @(ApiModelProperty@field)(position = 6, required = true)
    phones: Seq[Phone] = Seq.empty,

    @(ApiModelProperty@field)(position = 7, required = true)
    address: Option[Address] =None,

    @(ApiModelProperty@field)(position = 8, required = true)
    meetingRooms: Seq[MeetingRoom] = Seq.empty,

    @(ApiModelProperty@field)(position = 9, required = true, hidden = true)
    appInfo: Option[Map[String, List[JsValue]]] = None
)
