package com.pgi.gmsearch.contacts.api

import com.pgi.gmsearch.common.SearchObjectTypes.{Contacts, MeetingRooms, SearchObjectType}
import com.pgi.gmsearch.common._
import com.pgi.gmsearch.contacts.domain.{ApiContact, ApiContactConversions}
import com.pgi.gmsearch.infrastructure.play.bindables.SearchQueryParam
import com.pgi.gmsearch.repository.ElasticSearchRepository
import com.pgi.playframework.api.JsonConversions
import com.pgi.playframework.infrastructure.play.PlayLogging
import com.pgi.playframework.infrastructure.play.essentialactions.{EssentialActionBuilder, GlobalScopes}
import io.swagger.annotations._
import javax.inject.Inject
import javax.ws.rs.{PathParam, QueryParam}
import org.apache.http.HttpStatus
import play.api.Configuration
import play.api.mvc.{AbstractController, ControllerComponents, EssentialAction}

import scala.concurrent.ExecutionContext

object ContactsController {
  val ContactFilters = Map("userGroupId" -> KnownFields.UserGroupId)
}

@Api(value = "contacts")
class ContactsController @Inject()(cc: ControllerComponents, conf: Configuration, essentialActionBuilder: EssentialActionBuilder,
  elasticSearchRepository: ElasticSearchRepository)
  (implicit ec: ExecutionContext) extends AbstractController(cc) with JsonConversions with WithUserGroupId
  with ApiContactConversions with PlayLogging {

  @ApiOperation(nickname = "getContact", value = "Get a contact", httpMethod = "GET")
  @ApiResponses(Array(
    new ApiResponse(code = HttpStatus.SC_OK, message = "Contact", response = classOf[ApiContact]),
    new ApiResponse(code = HttpStatus.SC_NOT_FOUND, message = "Contact not found")
  ))
  def getContact(@ApiParam(value = "Contact ID") @PathParam("id") id: String,
    @ApiParam(value = "Further search query") @QueryParam("fq") fq: Seq[SearchQueryParam],
    @ApiParam(value = "Only Return IDs") @QueryParam("idsOnly") idsOnly: Boolean): EssentialAction =
    essentialActionBuilder.verifyAuthRequest(GMSearchScopes.GMSearch, GMSearchScopes.GMSearch_Internal, GlobalScopes.GMServices_Core) { implicit authRequest =>
      Action.async { implicit request =>
        val userGroupId = getUserGroupId(authRequest)
        elasticSearchRepository.getWithId[ApiContact](id, Contacts,
          filterMap = getFilterMap(Set(Contacts), userGroupId,
            searchQueryParams = if (!userGroupId.contains(KnownFieldValues.UserGroupId_Universal)) fq.filterNot(_.key == "userGroupId") else fq),
          idsOnly,
          excludes = if (!authRequest.scopes.contains(GMSearchScopes.GMSearch_Internal)) Seq(KnownFields.AppInfo) else Seq.empty).map {
          case Some(contact) => getJsonResponse(toJson(contact), HttpStatus.SC_OK)
          case _ => NotFound
        }.recover {
          case ex: Exception =>
            logger.warn(s"Error occurred while getting contact with ID: $id", ex)
            InternalServerError(s"Error occurred while getting contact with ID: $id")
        }
      }
    }

  private def getFilterMap(searchObjectTypes: Set[SearchObjectType], userGroupId: Set[String], searchQueryParams: Seq[SearchQueryParam]): Map[FilterField, Set[String]] = {
    val filterMap = if (!userGroupId.contains(KnownFieldValues.UserGroupId_Universal))
      Map(FilterField(Contacts, KnownFields.UserGroupId) -> userGroupId)
    else Map.empty

    filterMap ++ (searchObjectTypes.toList match {
      case Contacts :: Nil => searchQueryParams.flatMap(p =>
        ContactsController.ContactFilters.get(p.key).map(f => SearchQueryParam(f, p.value))).
        map(p => FilterField(Contacts, p.key) -> p.value).toMap
      case _ => Map.empty[FilterField, Set[String]]
    })
  }

}
