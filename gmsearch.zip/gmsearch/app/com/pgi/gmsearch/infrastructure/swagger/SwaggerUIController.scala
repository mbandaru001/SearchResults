package com.pgi.gmsearch.infrastructure.swagger

import javax.inject.Inject

import com.pgi.playframework.infrastructure.play.essentialactions.EssentialActionBuilder
import play.api.mvc.InjectedController

class SwaggerUIController @Inject() (essentialActionBuilder: EssentialActionBuilder) extends InjectedController {
  def index = essentialActionBuilder.noAuthRequest { implicit request =>
    Action { implicit request =>
      val swaggerApiDocs =
        com.pgi.playframework.infrastructure.swagger.routes.SwaggerApiHelpController.getSwaggerResources().
          absoluteURL(request.secure)

      Ok(views.html.index(swaggerApiDocs))
    }
  }
}
