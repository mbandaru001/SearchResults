package com.pgi.gmsearch.infrastructure.elasticsearch

import org.elasticsearch.action.ActionListener

import scala.concurrent.{Future, Promise}

trait ElasticSearchAsyncConverter {
  private class ElasticSearchAsyncPromiseHandler[T](promise: Promise[T]) extends ActionListener[T] {
    def onResponse(s: T): Unit = promise.success(s)
    def onFailure(ex: Exception): Unit = promise.failure(ex)
  }

  def elasticSearchToScala[R, T](fn: Function2[R, ActionListener[T], Unit]): Function1[R, Future[T]] = { req =>
    val p = Promise[T]
    fn(req, new ElasticSearchAsyncPromiseHandler(p))
    p.future
  }
}