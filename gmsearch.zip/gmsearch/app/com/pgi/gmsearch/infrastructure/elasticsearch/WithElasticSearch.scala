package com.pgi.gmsearch.infrastructure.elasticsearch

import com.pgi.gmsearch.common.SearchObjectTypes.SearchObjectType
import com.pgi.gmsearch.common.{JsSearchValueWithId, JsSearchValueWithIdList, JsValueWithId, JsValueWithIdList}
import org.apache.http.HttpHeaders.CONTENT_TYPE
import org.apache.http.entity.ContentType.APPLICATION_JSON
import org.elasticsearch.action.search.{SearchRequest, SearchResponse}
import org.elasticsearch.client.{RequestOptions, RestHighLevelClient}
import play.api.Configuration
import play.api.libs.json._

import scala.collection.JavaConverters._
import scala.concurrent.{ExecutionContext, Future}

trait WithElasticSearch extends ElasticSearchAsyncConverter {
  implicit val ec: ExecutionContext

  val esRestClient: RestHighLevelClient
  val conf: Configuration

  def getSearchObjectType(clusterAlias: String): SearchObjectType

  def executeSearchAsync(searchRequest: SearchRequest): Future[JsValueWithIdList] = {
    val requestOptionsBuilder = RequestOptions.DEFAULT.toBuilder
    requestOptionsBuilder.addHeader(CONTENT_TYPE, APPLICATION_JSON.toString)
    elasticSearchToScala[SearchRequest, SearchResponse](esRestClient.searchAsync(_, requestOptionsBuilder.build(), _))(searchRequest).map { res =>
      JsValueWithIdList(res.getHits.getTotalHits,
        res.getHits.getHits.toSeq.map(h => JsValueWithId(getSearchObjectType(Option(h.getClusterAlias).getOrElse(h.getIndex)), h.getId,
          Option(h.getSourceAsString).map(Json.parse))))
    }
  }

  def executePaginatedSearchAsync(searchRequest: SearchRequest, hl: Boolean = false): Future[JsSearchValueWithIdList] = {
    val requestOptionsBuilder = RequestOptions.DEFAULT.toBuilder
    requestOptionsBuilder.addHeader(CONTENT_TYPE, APPLICATION_JSON.toString)
    elasticSearchToScala[SearchRequest, SearchResponse](esRestClient.searchAsync(_, requestOptionsBuilder.build(), _))(searchRequest).map { res =>
      JsSearchValueWithIdList(res.getHits.getTotalHits,
        res.getHits.getHits.toSeq.map(h => JsSearchValueWithId(getSearchObjectType(Option(h.getClusterAlias).getOrElse(h.getIndex)), h.getId,
          Json.parse(h.getSourceAsString),
          h.getHighlightFields.values.asScala.map(hl => hl.getName -> hl.getFragments.toSeq.map(_.toString)).toMap)))
    }
  }
}