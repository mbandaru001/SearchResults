package com.pgi.gmsearch.infrastructure.play.bindables

import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import play.api.mvc.QueryStringBindable

case class SearchQueryParam(key: String, value: Set[String])

object SearchQueryParam {

  implicit def searchQueryParamsBinder(implicit stringBinder: QueryStringBindable[Seq[String]]) =
    new QueryStringBindable[Seq[SearchQueryParam]] {

      override def bind(key: String, params: Map[String, Seq[String]]): Option[Either[String, Seq[SearchQueryParam]]] = {
        val searchQueryParams = params.filter(_._1.startsWith(s"$key.")).filter(_._1.length >= key.length + 2).map {
          case (k, v) => k.substring(key.length + 1) -> v
        }.map {
          case (k, v) => SearchQueryParam(k, v.toSet)
        }.toSeq

        Some(Right(searchQueryParams))
      }

      override def unbind(key: String, searchQueryParams: Seq[SearchQueryParam]): String =
        searchQueryParams.
          map(p => p.value.map(v => s"$key.${p.key}=${URLEncoder.encode(v, StandardCharsets.UTF_8.name)}").mkString("&")).
          mkString("&")
    }
}
