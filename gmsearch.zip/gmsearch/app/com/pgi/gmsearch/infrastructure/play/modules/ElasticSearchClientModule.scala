package com.pgi.gmsearch.infrastructure.play.modules

import com.google.inject.AbstractModule
import org.elasticsearch.client.RestHighLevelClient

class ElasticSearchClientModule extends AbstractModule {
  override def configure(): Unit =
    bind(classOf[RestHighLevelClient]).toProvider(classOf[ElasticSearchClientProvider]).asEagerSingleton()
}
