package com.pgi.gmsearch.infrastructure.play.modules

import com.amazonaws.auth.{AWS4Signer, AWSCredentialsProvider}
import javax.inject.Inject
import com.google.inject.Provider
import com.pgi.gmsearch.infrastructure.amazonws.AWSRequestSigningApacheInterceptor
import org.apache.http.HttpHost
import org.elasticsearch.client.{RestClient, RestHighLevelClient}
import play.api.Configuration

class ElasticSearchClientProvider @Inject() (credentialsProvider: AWSCredentialsProvider, conf: Configuration)
  extends Provider[RestHighLevelClient] {
  final val ServiceName = "es"

  lazy val esRestClient = {
    val local = conf.get[Boolean]("aws.elasticsearch.local")
    val region = conf.get[String]("aws.elasticsearch.region")
    val endpoint = conf.get[String]("aws.elasticsearch.endpoint")

    val lowLevelClient = RestClient.builder(HttpHost.create(endpoint))

    val authLowLevelClient = if (local) lowLevelClient else {
      val signer = new AWS4Signer()
      signer.setServiceName(ServiceName)
      signer.setRegionName(region)
      val interceptor = new AWSRequestSigningApacheInterceptor(ServiceName, signer, credentialsProvider)

      lowLevelClient.setHttpClientConfigCallback(_.addInterceptorFirst(interceptor))
    }

    new RestHighLevelClient(authLowLevelClient)
  }

  override def get(): RestHighLevelClient = esRestClient
}
