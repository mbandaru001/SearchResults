package com.pgi.gmsearch.search.api

import com.pgi.gmsearch.common.NameOrders.{Eastern, NameOrder, Western}
import com.pgi.gmsearch.common.SearchObjectTypes.{Contacts, MeetingRooms, SearchObjectType}
import com.pgi.gmsearch.common._
import com.pgi.gmsearch.common.errors.ParameterParseException
import com.pgi.gmsearch.infrastructure.play.bindables.SearchQueryParam
import com.pgi.gmsearch.repository.ElasticSearchRepository
import com.pgi.gmsearch.search.domain.{ApiSearchConversions, ApiSearchResponseItem, ApiSearchResponseList}
import com.pgi.playframework.api.JsonConversions
import com.pgi.playframework.infrastructure.play.PlayLogging
import com.pgi.playframework.infrastructure.play.essentialactions.{EssentialActionBuilder, GlobalScopes}
import io.swagger.annotations._
import javax.inject.Inject
import javax.ws.rs.QueryParam
import org.apache.http.HttpStatus
import play.api.Configuration
import play.api.libs.json
import play.api.libs.json.{JsArray, JsValue}
import play.api.mvc.{AbstractController, ControllerComponents, RequestHeader}

import scala.concurrent.ExecutionContext

object SearchController {
  val ContactFilters = Map("email" -> KnownFields.OwnerEmail, "userGroupId" -> KnownFields.UserGroupId)
}

@Api(value = "search")
class SearchController @Inject() (cc: ControllerComponents, conf: Configuration, essentialActionBuilder: EssentialActionBuilder,
    elasticSearchRepository: ElasticSearchRepository)
  (implicit ec: ExecutionContext) extends AbstractController(cc) with JsonConversions with WithUserGroupId
  with ApiSearchConversions with PlayLogging {
  final val MaxSize = 30
  final val MaxFrom = 200

  @ApiOperation(nickname = "/search", value = "Get a search result with the given search criteria", httpMethod = "GET")
  @ApiResponses(Array(
    new ApiResponse(code = HttpStatus.SC_OK, message = "Search response list", response = classOf[ApiSearchResponseList])
  ))
  def search(@ApiParam(value = "Search query") @QueryParam("q") q: String,
             @ApiParam(value = "Further search query") @QueryParam("fq") fq: Seq[SearchQueryParam],
             @ApiParam(value = "Search document type") @QueryParam("t") t: Seq[String],
             @ApiParam(value = "Name order") @QueryParam("nameOrder") nameOrder: Option[String],
             @ApiParam(value = "Handle inactive records") @QueryParam("inactive") inactive: Option[String],
             @ApiParam(value = "Maximum result size", defaultValue = "10", allowableValues = "range[0, 30]") @QueryParam("size") size: Int,
             @ApiParam(value = "Starting point for results", defaultValue = "0", allowableValues = "range[0, 200]") @QueryParam("from") from: Int,
             @ApiParam(value = "Only Return IDs") @QueryParam("idsOnly") idsOnly: Boolean,
             @ApiParam(value = "Highlight matched suggestions") @QueryParam("hl") hl: Boolean) =
    performSearch(q, fq, t, nameOrder, size, from, idsOnly, hl, inactive, (res: ApiSearchResponseList) => toJson(res))

  @ApiOperation(nickname = "/suggest", value = "Get a search result with the given search criteria", httpMethod = "GET")
  @ApiResponses(Array(
    new ApiResponse(code = HttpStatus.SC_OK, message = "List of Search Response", response = classOf[List[ApiSearchResponseItem]])
  ))
  def suggest(@ApiParam(value = "Search query") @QueryParam("q") q: String,
             @ApiParam(value = "Further search query") @QueryParam("fq") fq: Seq[SearchQueryParam],
             @ApiParam(value = "Search document type") @QueryParam("t") t: Seq[String],
             @ApiParam(value = "Name order") @QueryParam("nameOrder") nameOrder: Option[String],
              @ApiParam(value = "Handle inactive records") @QueryParam("inactive") inactive: Option[String],
             @ApiParam(value = "Maximum result size", defaultValue = "10", allowableValues = "range[0, 30]") @QueryParam("size") size: Int,
             @ApiParam(value = "Starting point for results", defaultValue = "0", allowableValues = "range[0, 200]") @QueryParam("from") from: Int,
             @ApiParam(value = "Only Return IDs") @QueryParam("idsOnly") idsOnly: Boolean,
             @ApiParam(value = "Highlight matched suggestions") @QueryParam("hl") hl: Boolean) =
    performSearch(q, fq, t, nameOrder, size, from, idsOnly, hl, inactive, (res: ApiSearchResponseList) => JsArray(res.items.map(toJson(_))))

  private def performSearch(q: String, fq: Seq[SearchQueryParam], t: Seq[String], nameOrder: Option[String], size: Int,
      from: Int, idsOnly: Boolean, hl: Boolean, inactive: Option[String], jsConverter: ApiSearchResponseList => JsValue) =
    essentialActionBuilder.verifyAuthRequest(GMSearchScopes.GMSearch, GMSearchScopes.GMSearch_Internal, GlobalScopes.GMServices_Core) { implicit authRequest =>
      Action.async { implicit request =>
        val searchObjectTypes = parseSearchObjectType(t)
        val userGroupId = getUserGroupId(authRequest)
        elasticSearchRepository.search[ApiSearchResponseList](q, if (size > MaxSize) MaxSize else size,
          if (from > MaxFrom) MaxFrom else from,
          searchObjectTypes,
          filterMap = getFilterMap(searchObjectTypes, userGroupId,
            searchQueryParams = if (!userGroupId.contains(KnownFieldValues.UserGroupId_Universal)) fq.filterNot(_.key == "userGroupId") else fq,
            inactive),
          noFilterList = List(FilterField(MeetingRooms, KnownFields.MeetingRoomUrlSearch)),
          nameOrder = parseNameOrder(nameOrder),
          idsOnly = idsOnly,
          highlight = hl,
          excludes = if (!authRequest.scopes.contains(GMSearchScopes.GMSearch_Internal)) Seq(KnownFields.AppInfo) else Seq.empty).map(
          res => getJsonResponse(jsConverter(res), HttpStatus.SC_OK)
        ).recover {
          case ex: Exception =>
            logger.warn(s"Error occurred while getting search results with search text: $q", ex)
            InternalServerError(s"Error occurred while getting search results with search text: $q")
        }
      }
    }

  private def parseSearchObjectType(docType: Seq[String]): Set[SearchObjectType] =
    if (docType.isEmpty) Set(SearchObjectTypes.MeetingRooms) // This will be reverted back to AllSearchObjectTypes
    else docType.foldLeft(Set[SearchObjectType]()) {(acc, lt) => { lt.toLowerCase match {
      case SearchObjectTypes.MeetingRoomsIndex => acc + MeetingRooms
      case SearchObjectTypes.ContactsIndex => acc + Contacts
      //      case SearchObjectTypes.UploadedFilesIndex => acc + UploadedFiles
      case _ => throw ParameterParseException(s"$lt is not a valid search type", Map("t" -> lt))
    }}}

  private def parseNameOrder(nameOrder: Option[String]): NameOrder =
    nameOrder match {
      case Some(o) if o.toLowerCase == NameOrders.EasternOrder => Eastern
      case _ => Western
    }

  private def getFilterMap(searchObjectTypes: Set[SearchObjectType], userGroupId: Set[String],
                           searchQueryParams: Seq[SearchQueryParam], inactive: Option[String]): Map[FilterField, Set[String]] = {
    val filterMap = if(!userGroupId.contains(KnownFieldValues.UserGroupId_Universal)) Map(FilterField(MeetingRooms, KnownFields.UserGroupId) -> userGroupId,
      FilterField(Contacts, KnownFields.UserGroupId) -> userGroupId) else Map.empty

    val inactiveMap = inactive match {
      case Some(s) if s == "any" => Map.empty
      case Some(s) if s == "true" => Map(FilterField(MeetingRooms, KnownFields.Inactive) -> Set(true.toString),
        FilterField(Contacts, KnownFields.Inactive) -> Set(true.toString))
      case _ => Map(FilterField(MeetingRooms, KnownFields.Inactive) -> Set(false.toString),
        FilterField(Contacts, KnownFields.Inactive) -> Set(false.toString))
    }

    filterMap ++ inactiveMap ++ (searchObjectTypes.toList match {
      case Contacts::Nil => searchQueryParams.flatMap(p =>
        SearchController.ContactFilters.get(p.key).map(f => SearchQueryParam(f, p.value))).
        map(p => FilterField(Contacts, p.key) -> p.value).toMap
      case _ => Map.empty[FilterField, Set[String]]
    })
  }
}
