package com.pgi.gmsearch.search.domain

import ai.x.play.json.Jsonx
import com.pgi.playframework.domain.ApiObject
import io.swagger.annotations.{ApiModel, ApiModelProperty}

import scala.annotation.meta.field

object ApiSearchResponseList {
  implicit lazy val searchResponseListFormat = Jsonx.formatCaseClass[ApiSearchResponseList]
}

@ApiModel(value = "Paginated Search Results")
case class ApiSearchResponseList(
                                  @(ApiModelProperty@field)(position = 1, required = true)
                                  totalCount: Long,

                                  @(ApiModelProperty@field)(position = 2, required = true)
                                  items: Seq[ApiSearchResponseItem]
                                ) extends ApiObject
