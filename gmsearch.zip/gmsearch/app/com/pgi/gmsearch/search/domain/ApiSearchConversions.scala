package com.pgi.gmsearch.search.domain

import com.pgi.gmsearch.common.NameOrders.NameOrder
import com.pgi.gmsearch.common.SearchObjectTypes.{Contacts, MeetingRooms}
import com.pgi.gmsearch.common.domain.{ApiConversions, ApiResponseMetadata, Image, OptionalJsValueMetadata, OptionalStrMetadata, StrMetadata}
import com.pgi.gmsearch.common.errors.ElasticSearchResultException
import com.pgi.gmsearch.common.{JsSearchValueWithId, JsSearchValueWithIdList, JsValueWithIdList}
import com.pgi.gmsearch.contacts.domain.ApiContact
import com.pgi.gmsearch.meetingrooms.domain.ApiMeetingRoom
import com.pgi.playframework.infrastructure.play.PlayLogging
import play.api.libs.functional.syntax._
import play.api.libs.json._

import scala.language.implicitConversions

trait ApiSearchConversions extends ApiConversions with PlayLogging {

  implicit def convertToPaginatedSuggestResponse(result: JsSearchValueWithIdList, nameOrder: NameOrder): ApiSearchResponseList = {
    def meetingRoomReads(id: String, hl: Map[String, Seq[String]]): Reads[ApiSearchResponseItem] = {
      def getOwnerName = hl.get(s"${nameOrder.ownerNameField}.autocomplete").flatMap(_.headOption).map(Reads.pure(_)).
        orElse(hl.get("ownerFamilyName.autocomplete").flatMap(_.headOption).map(lname => (__ \ "ownerGivenName").read[String].map(fname => s"$fname $lname"))).
        orElse(hl.get(s"${nameOrder.ownerNameField}.autocompleteWs").flatMap(_.headOption).map(Reads.pure(_))).
        getOrElse((__ \ nameOrder.ownerNameField).read[String])
      def getMeetingRoomUrl = hl.get("meetingRoomUrl.highlight").flatMap(_.headOption).map(Reads.pure(_)).
        orElse(hl.get("meetingRoomUrlRoomName.autocomplete").flatMap(_.headOption).map(room => (__ \ "meetingRoomUrlBase").read[String].map(base => s"$base/$room"))).
        getOrElse((__ \ "meetingRoomUrlOrig").read[String].orElse((__ \ "meetingRoomUrl").read[String])).map(Some(_))
      (
        Reads.pure(id) and
          Reads.pure(ApiMeetingRoom.getMeetingRoomUrl(id)) and
          Reads.pure(ApiMeetingRoom.ResourceType) and
          getOwnerName and
          getMeetingRoomUrl and (__ \ "meetingRoomUrlOrig").read[String].orElse((__ \ "meetingRoomUrl").read[String]).map(Some(_)) and
          (__ \ "profileImageUrls").read[Seq[Image]].map(getImageUrl) and
          (__ \ "inactive").readNullable[Boolean].map(_.getOrElse(false)) and
          meetingRooomMetadataReads
        )(ApiSearchResponseItem.apply _)
    }

    def contactReads(id: String, hl: Map[String, Seq[String]]): Reads[ApiSearchResponseItem] = {
      def getName = hl.get(s"${nameOrder.ownerNameField}.autocomplete").flatMap(_.headOption)
        .map(Reads.pure(_)).orElse(hl.get("ownerFamilyName.autocomplete").flatMap(_.headOption)
        .map(lname => (__ \ "ownerGivenName").read[String].map(fname => s"$fname $lname")))
        .orElse(hl.get(s"${nameOrder.ownerNameField}.autocompleteWs").flatMap(_.headOption).map(Reads.pure(_))).
        getOrElse((__ \ nameOrder.ownerNameField).read[String])

      def getEmail = hl.get("ownerEmail.autocomplete").flatMap(_.headOption).map(Reads.pure(_)).
        getOrElse((__ \ "ownerEmail").read[String]).map(Some(_))

      (
        Reads.pure(id) and
          Reads.pure(ApiContact.getContactUrl(id)) and
          Reads.pure(ApiContact.ResourceType) and
          getName and
          getEmail and
          Reads.pure(None) and
          (__ \ "profileImageUrls").read[Seq[Image]].map(getImageUrl) and
          (__ \ "inactive").readNullable[Boolean].map(_.getOrElse(false)) and
          contactMetadataReads
        ) (ApiSearchResponseItem.apply _)
    }

    ApiSearchResponseList(
      result.totalCount,
      result.items.map { res =>
        implicit val jsonSearchResultReader: Reads[ApiSearchResponseItem] = (res.searchObjectType match {
          case MeetingRooms => meetingRoomReads _
          case Contacts => contactReads _
        })(res.id, res.highlight)

        res.json.validate[ApiSearchResponseItem] match {
          case JsSuccess(room, _) => room
          case JsError(ex) =>
            ex.flatMap(e => e._2.map(v => e._1 -> v)).foreach { error =>
              logger.info(s"Error parsing ${error._1.toString()}: ${error._2.message}")
            }
            throw ElasticSearchResultException(s"Could not parse JSON from ElasticSearch: ${res.json.toString}")
        }
      }
    )
  }

  private def getImageUrl(imgs: Seq[Image]): Option[String] =
    imgs.find(_.isDefault).orElse(imgs.headOption).map(_.imageUrl)

  private def meetingRooomMetadataReads: Reads[Map[String, ApiResponseMetadata]] =
    (
      (__ \ "meetingRoomType").read[String].map(StrMetadata) and
        (__ \ "webMeetingServer").read[String].map(StrMetadata) and
        (__ \ "conferenceType").read[String].map(StrMetadata) and
        (__ \ "conferenceId").read[String].map(StrMetadata)
      )((mt, ms, ct, cid) =>
      Map(
        "meetingRoomType" -> mt,
        "webMeetingServer" -> ms,
        "conferenceType" -> ct,
        "conferenceId" -> cid
      )
    )

  private def contactMetadataReads: Reads[Map[String, ApiResponseMetadata]] =
    (
      (__ \ "ownerEmail").read[String].map(StrMetadata) and
        (__ \ "ownerGivenName").readNullable[String].map(OptionalStrMetadata) and
        (__ \ "ownerFamilyName").readNullable[String].map(OptionalStrMetadata) and
        (__ \ "meetingRooms").readNullable[JsValue].map(OptionalJsValueMetadata) and
        (__ \ "jobTitle").readNullable[String].map(OptionalStrMetadata) and
        (__ \ "phones").readNullable[JsValue].map(OptionalJsValueMetadata) and
        (__ \ "address").readNullable[JsValue].map(OptionalJsValueMetadata) and
        (__ \ "appInfo").readNullable[JsValue].map(OptionalJsValueMetadata)
      )((e, gn, fn, mr, jt, ph, add, ai) =>
      Map(
        "email" -> e,
        "givenNamme" -> gn,
        "familyName" -> fn,
        "meetingRooms" -> mr,
        "jobTitle" -> jt,
        "phones" -> ph,
        "address" -> add,
        "appInfo" -> ai
      ).filterNot {
        case (_, v) => v.toJsValue == JsNull
      }
    )
}
