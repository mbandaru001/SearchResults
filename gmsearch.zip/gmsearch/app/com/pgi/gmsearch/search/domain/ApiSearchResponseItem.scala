package com.pgi.gmsearch.search.domain


import ai.x.play.json.Jsonx
import com.pgi.gmsearch.common.domain.{ApiResponseMetadata, Image}
import com.pgi.playframework.domain.ApiObject
import io.swagger.annotations.{ApiModel, ApiModelProperty}

import scala.annotation.meta.field

object ApiSearchResponseItem {
  implicit lazy val searchResponseItemFormat = Jsonx.formatCaseClass[ApiSearchResponseItem]
}

@ApiModel(value = "SearchResult")
case class ApiSearchResponseItem(
                                  @(ApiModelProperty@field)(position = 1, required = true)
                                  id: String,

                                  @(ApiModelProperty@field)(position = 2, required = true)
                                  resourceUri: String,

                                  @(ApiModelProperty@field)(position = 3, required = true)
                                  resourceType: String,

                                  @(ApiModelProperty@field)(position = 4, required = true)
                                  title: String,

                                  @(ApiModelProperty@field)(position = 5, required = false)
                                  secondaryTitle: Option[String] = None,

                                  @(ApiModelProperty@field)(position = 6, required = false)
                                  externalUrl: Option[String] = None,

                                  @(ApiModelProperty@field)(position = 7, required = false)
                                  imageUrl: Option[String] = None,

                                  @(ApiModelProperty@field)(position = 8, required = false)
                                  inactive: Boolean = false,

                                  @(ApiModelProperty@field)(position = 9, required = true)
                                  metadata: Map[String, ApiResponseMetadata] = Map.empty
                                ) extends ApiObject