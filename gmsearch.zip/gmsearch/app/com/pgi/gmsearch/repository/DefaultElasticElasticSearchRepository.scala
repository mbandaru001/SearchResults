package com.pgi.gmsearch.repository

import com.pgi.gmsearch.common.NameOrders.NameOrder
import com.pgi.gmsearch.common.SearchObjectTypes.{Contacts, MeetingRooms, SearchObjectType}
import com.pgi.gmsearch.common._
import com.pgi.gmsearch.infrastructure.elasticsearch.WithElasticSearch
import com.pgi.playframework.infrastructure.play.PlayLogging
import javax.inject.Inject
import org.elasticsearch.action.search.SearchRequest
import org.elasticsearch.client.RestHighLevelClient
import org.elasticsearch.index.query.QueryBuilders._
import org.elasticsearch.index.query.{BoolQueryBuilder, MultiMatchQueryBuilder, Operator, QueryBuilder}
import org.elasticsearch.search.builder.SearchSourceBuilder
import org.elasticsearch.search.fetch.subphase.FetchSourceContext
import org.elasticsearch.search.fetch.subphase.highlight.HighlightBuilder
import play.api.Configuration

import scala.concurrent.{ExecutionContext, Future}
import scala.util.Try

class DefaultElasticElasticSearchRepository @Inject()(val esRestClient: RestHighLevelClient, val conf: Configuration)
  (implicit val ec: ExecutionContext)
  extends ElasticSearchRepository with WithElasticSearch with PlayLogging {

  def bestFieldsSearchList(nameOrder: NameOrder): Seq[String] = Set(
    "ownerEmail",
    nameOrder.ownerNameField,
    "meetingRoomUrl",
    "meetingRoomUrlRoomName"
  ).toSeq

  def bestFieldsSuggestList(nameOrder: NameOrder): Seq[String] = Set(
    "ownerEmail",
    "ownerEmail.autocomplete",
    nameOrder.ownerNameField,
    s"${nameOrder.ownerNameField}.autocomplete",
    s"${nameOrder.ownerNameField}.autocompleteWs",
    "ownerFamilyName.autocomplete",
    "ownerFamilyName.autocompleteWs",
    "meetingRoomUrl",
    "meetingRoomUrl.autocomplete",
    "meetingRoomUrlRoomName",
    "meetingRoomUrlRoomName.autocomplete"
  ).toSeq

  final val PreHlTag = "[hl+]"
  final val PostHlTag = "[+hl]"

  override def getSearchObjectType(clusterAlias: String): SearchObjectType =
    clusterAlias match {
      case SearchObjectTypes.ContactsIndex => Contacts
      case SearchObjectTypes.MeetingRoomsIndex => MeetingRooms
      //      case SearchObjectTypes.UploadedFilesIndex => UploadedFiles
    }

  def getWithId[T](id: String, searchObjectType: SearchObjectType, filterMap: Map[FilterField, Set[String]], idsOnly: Boolean,
    includes: Seq[String] = Seq.empty, excludes: Seq[String] = Seq.empty)
    (implicit converter: JsValueWithId => T): Future[Option[T]] =
    getWithField(IdField, id, searchObjectType, filterMap, idsOnly, includes, excludes)

  def getWithField[T](field: String, value: String, searchObjectType: SearchObjectType, filterMap: Map[FilterField, Set[String]],
      idsOnly: Boolean, includes: Seq[String] = Seq.empty,
      excludes: Seq[String] = Seq.empty)(implicit converter: JsValueWithId => T): Future[Option[T]] = {

    val filter = filterMap.foldLeft(Map[String, BoolQueryBuilder]()) { (acc, fm) => {
      acc + (fm._1.field -> fm._2.foldLeft(boolQuery()) { (nbq, v) => nbq should termQuery(fm._1.field, v) })
    }}.foldLeft(boolQuery().must(matchQuery(field, value))) { (bq, mfbq) => bq must mfbq._2 }

    val fetchSourceContext = new FetchSourceContext(!idsOnly, includes.toArray, excludes.toArray)
    val qb = constantScoreQuery(filter)
    val src = new SearchSourceBuilder().fetchSource(fetchSourceContext).query(qb)
    val searchRequest = new SearchRequest().indices(searchObjectType.index).source(src)
    executeSearchAsync(searchRequest).map(_.items.headOption.map(converter))
  }

  def search[T](queryText: String, size: Int, from: Int,
                               searchObjectTypes: Set[SearchObjectType] = SearchObjectTypes.AllSearchObjectTypes,
                               filterMap: Map[FilterField, Set[String]], noFilterList: List[FilterField], nameOrder: NameOrder,
                               idsOnly: Boolean = false, highlight: Boolean = false, includes: Seq[String] = Seq.empty,
                               excludes: Seq[String] = Seq.empty)(implicit converter: (JsSearchValueWithIdList, NameOrder) => T): Future[T] = {
    def getIndices = searchObjectTypes.map(_.index).toSeq

    implicit class SearchSourceOps(searchSource: SearchSourceBuilder) {
      def withHighlighter: SearchSourceBuilder = if (highlight) {
        val hb = new HighlightBuilder().forceSource(true).preTags(PreHlTag).postTags(PostHlTag).
          numOfFragments(1).
          field(new HighlightBuilder.Field(s"${nameOrder.ownerNameField}.autocompleteWs")).
          field(new HighlightBuilder.Field(s"${nameOrder.ownerNameField}.autocomplete")).
          field(new HighlightBuilder.Field("ownerFamilyName.autocomplete")).
          field(new HighlightBuilder.Field("meetingRoomUrl.highlight").requireFieldMatch(false).
            highlightQuery(matchQuery("meetingRoomUrl.highlight", queryText))).
          field(new HighlightBuilder.Field("meetingRoomUrlRoomName.autocomplete")).
          field(new HighlightBuilder.Field("ownerEmail.autocomplete"))
        searchSource.highlighter(hb)
      } else searchSource
    }

    val queryBuilder = queryText match {
      case "*" =>  matchAllQuery()
      case _ =>  multiMatchQuery(queryText, bestFieldsSuggestList(nameOrder): _*).`type`(MultiMatchQueryBuilder.Type.BEST_FIELDS).
        operator(Operator.AND)
    }

    val fetchSourceContext = new FetchSourceContext(!idsOnly, includes.toArray, excludes.toArray)

    val query = createUnfilteredQuery(createFilteredQuery(queryBuilder, filterMap), noFilterList, queryText)

    val searchSource = new SearchSourceBuilder().size(size).from(from).fetchSource(fetchSourceContext).query(query).withHighlighter
    val searchRequest = new SearchRequest().indices(getIndices: _*).source(searchSource)

    executePaginatedSearchAsync(searchRequest).map(converter(_, nameOrder))
  }

  def createUnfilteredQuery(query: BoolQueryBuilder, noFilterList: List[FilterField], queryText: String): BoolQueryBuilder = {
    noFilterList.foldLeft(boolQuery().should(query)) { (acc, lt) => {
      val noFilterQuery =
        boolQuery().must(termQuery(DocTypeField, lt.searchObjectType.index)).must(matchQuery(lt.field, queryText))

      acc.should(noFilterQuery)
    }}
  }

  /**
    * This function creates a filtered ES query based on the filterMap provided and the
    * base accumulator query, in this case a MultiMatchQuery.
    *
    * @param query query accumulator
    * @param filterMap filter
    * @return
    */
  private def createFilteredQuery(query: QueryBuilder, filterMap: Map[FilterField, Set[String]]) =
    filterMap.foldLeft(Map[SearchObjectType, BoolQueryBuilder]()) { (acc, fm) => {
      // for each SearchObjectType create bool query of musts from fields
      val bq = acc.get(fm._1.searchObjectType) match {
        case Some(xs) => xs
        case None => boolQuery()
      }
      acc + (fm._1.searchObjectType -> bq.must(fm._2.foldLeft(boolQuery()) { (a, i) =>
        // filter on inactive field should only be applied if it is present in the record, if not present the record will
        // not be filtered for that field but will be fetched and treated as active. But for the case of inactive=true, we don't need to
        // include inactive field in should.must_not, that ways it will be ignored by default and won't be
        // wrongly fetched. We are doing this to identify all the records that don't have inactive field set as active records.
        if (fm._1.field == KnownFields.Inactive) {
          val fieldMayNotExist = boolQuery().mustNot(existsQuery(KnownFields.Inactive))
          fm._2.headOption match {
            case Some("false") => a.should(termQuery(fm._1.field, i)).should(fieldMayNotExist)
            case _ => a.should(termQuery(fm._1.field, i))
          }
        }
        else a.should(termQuery(fm._1.field, i))
      }))
    }}.foldLeft(boolQuery().must(query)) { (acc, sbMap) => {
      // create bool queries which filter only on a particular index
      // must apply all filter termQueries to the _index field
      val mustQuery = sbMap._2.must(termQuery(DocTypeField, sbMap._1.index))
      // must apply termQuery to all other _index
      val mustNotQuery = boolQuery().mustNot(termQuery(DocTypeField, sbMap._1.index))
      // should apply where either _index does match alongwith with the filter or _index does not match
      val shouldOnlyQuery = boolQuery().should(mustQuery).should(mustNotQuery)
      acc.filter(shouldOnlyQuery)
    }}

}
