package com.pgi.gmsearch.repository

import com.google.inject.ImplementedBy
import com.pgi.gmsearch.common.NameOrders.NameOrder
import com.pgi.gmsearch.common.SearchObjectTypes.SearchObjectType
import com.pgi.gmsearch.common._

import scala.concurrent.Future

@ImplementedBy(classOf[DefaultElasticElasticSearchRepository])
trait ElasticSearchRepository {
  final val DocTypeField = "docType"
  final val IdField = "_id"

  def getWithId[T](id: String, searchObjectType: SearchObjectType, filterMap: Map[FilterField, Set[String]], idsOnly: Boolean,
                   includes: Seq[String] = Seq.empty, excludes: Seq[String] = Seq.empty)
                  (implicit converter: JsValueWithId => T): Future[Option[T]]

  def getWithField[T](field: String, value: String, searchObjectType: SearchObjectType,
                      filterMap: Map[FilterField, Set[String]], idsOnly: Boolean = false, includes: Seq[String] = Seq.empty,
                      excludes: Seq[String] = Seq.empty)
                     (implicit converter: JsValueWithId => T): Future[Option[T]]

  def search[T](queryText: String, size: Int, from: Int,
                searchObjectTypes: Set[SearchObjectType] = SearchObjectTypes.AllSearchObjectTypes,
                filterMap: Map[FilterField, Set[String]], noFilterList: List[FilterField], nameOrder: NameOrder,
                idsOnly: Boolean = false, highlight: Boolean = false, includes: Seq[String] = Seq.empty,
                excludes: Seq[String] = Seq.empty)(implicit converter: (JsSearchValueWithIdList, NameOrder) => T): Future[T]
}