package com.pgi.gmsearch.common

import com.pgi.gmsearch.common.errors.ParameterParseException
import com.pgi.playframework.api.JsonConversions
import com.pgi.playframework.infrastructure.play.PlayLogging
import javax.inject.{Inject, Provider}
import play.api.http.DefaultHttpErrorHandler
import play.api.mvc.Results._
import play.api.mvc.{RequestHeader, Result}
import play.api.routing.Router
import play.api.{Configuration, Environment, OptionalSourceMapper}

import scala.concurrent.{ExecutionContext, Future}

class ErrorHandler @Inject() (env: Environment,
                              conf: Configuration,
                              sourceMapper: OptionalSourceMapper,
                              router: Provider[Router])
                             (implicit ec: ExecutionContext) extends DefaultHttpErrorHandler(env, conf, sourceMapper, router)
  with JsonConversions with PlayLogging {

  override def onServerError(request: RequestHeader, exception: Throwable): Future[Result] = {
    implicit val requestHeader: RequestHeader = request

    exception match {
      case ex: ParameterParseException =>
        logger.error(ex.msg)(createMarker(ex.customFields, ex.tags))
        Future.successful(BadRequest(ex.msg))
      case t: Throwable =>
        logger.error(t.getMessage, t)
        Future.successful(InternalServerError("An error occured while processing your request. Please try again later."))
    }

  }

}
