package com.pgi.gmsearch.common

import com.pgi.gmsearch.common.SearchObjectTypes.SearchObjectType
import play.api.libs.json.JsValue

case class JsValueWithId(searchObjectType: SearchObjectType, id: String, json: Option[JsValue])