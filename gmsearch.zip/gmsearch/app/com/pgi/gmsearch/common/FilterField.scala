package com.pgi.gmsearch.common

import com.pgi.gmsearch.common.SearchObjectTypes.SearchObjectType

case class FilterField(searchObjectType: SearchObjectType, field: String)
