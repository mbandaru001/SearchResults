package com.pgi.gmsearch.common

object KnownFieldValues {
  final val UserGroupId_Universal = "universal"
  final val UserGroupId_Any = "any"
}
