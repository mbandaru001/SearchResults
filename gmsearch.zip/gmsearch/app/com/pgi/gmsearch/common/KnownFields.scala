package com.pgi.gmsearch.common

object KnownFields {
  final val MeetingRoomUrlSearch: String = "meetingRoomUrl"
  final val UserGroupId = "userGroupId"
  final val OwnerEmail = "ownerEmail"
  final val AppInfo = "appInfo"
  final val Inactive = "inactive"
}
