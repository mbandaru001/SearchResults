package com.pgi.gmsearch.common

import com.pgi.playframework.infrastructure.play.essentialactions.requests.AuthRequest

trait WithUserGroupId {
  def getUserGroupId(authRequest: AuthRequest): Set[String] =
    Option(authRequest.identity.accessToken.getJWTClaimsSet.getStringClaim("pgi_id_user_group")).getOrElse("").split(" ").toSet
}
