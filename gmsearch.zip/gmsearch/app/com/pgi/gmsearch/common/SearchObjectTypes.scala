package com.pgi.gmsearch.common

object SearchObjectTypes {
  final val ContactsIndex = "contacts"
  final val MeetingRoomsIndex = "meetingrooms"
  final val UploadedFilesIndex = "files"

  final val AllSearchObjectTypes: Set[SearchObjectType] = Set(Contacts, MeetingRooms)

  sealed trait SearchObjectType { def index: String }
  case object Contacts extends SearchObjectType { final val index = ContactsIndex }
  case object MeetingRooms extends SearchObjectType { final val index = MeetingRoomsIndex }
//  case object UploadedFiles extends SearchObjectType { final val index = UploadedFilesIndex }
}