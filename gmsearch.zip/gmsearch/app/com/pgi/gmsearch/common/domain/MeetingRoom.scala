package com.pgi.gmsearch.common.domain

import ai.x.play.json.Jsonx
import io.swagger.annotations.{ApiModel, ApiModelProperty}

import scala.annotation.meta.field

object MeetingRoom {
  implicit lazy val meetingRoomFormats = Jsonx.formatCaseClassUseDefaults[MeetingRoom]
}

@ApiModel(value = "SimpleMeetingRoom")
case class MeetingRoom(
    @(ApiModelProperty @field)(position = 1, required = true)
    meetingRoomId: String,

    @(ApiModelProperty @field)(position = 2, required = true)
    meetingRoomType: String,

    @(ApiModelProperty @field)(position = 3, required = true)
    meetingRoomName: String,

    @(ApiModelProperty @field)(position = 4, required = true)
    meetingRoomUrl: String
)
