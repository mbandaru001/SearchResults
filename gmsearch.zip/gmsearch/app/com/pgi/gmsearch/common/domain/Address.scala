package com.pgi.gmsearch.common.domain

import ai.x.play.json.Jsonx
import io.swagger.annotations.{ApiModel, ApiModelProperty}

import scala.annotation.meta.field

object Address {
  implicit lazy val addressFormats = Jsonx.formatCaseClassUseDefaults[Address]
}

@ApiModel(value = "Address")
case class Address(
    @(ApiModelProperty @field)(position = 1, required = true)
    localParts: Seq[String],

    @(ApiModelProperty @field)(position = 2, required = true)
    city: String,

    @(ApiModelProperty @field)(position = 3, required = true)
    region: Option[String],

    @(ApiModelProperty @field)(position = 4, required = true)
    postalCode: Option[String],

    @(ApiModelProperty @field)(position = 5, required = true)
    country: String
)
