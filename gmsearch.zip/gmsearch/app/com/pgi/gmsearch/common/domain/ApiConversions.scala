package com.pgi.gmsearch.common.domain

import play.api.libs.json.{Reads, _}
import play.api.libs.functional.syntax._
import play.api.libs.json._

trait ApiConversions {
  implicit def imageReads: Reads[Image] = (
    (__ \ "imageUrl").read[String] and
      (__ \ "isDefault").read[Boolean]
    )(Image.apply _)

  implicit def phoneReads: Reads[Phone] = (
    (__ \ "number").read[String] and
      (__ \ "phoneType").readNullable[String] and
      (__ \ "isDefault").read[Boolean]
    )(Phone.apply _)

  implicit def addressReads: Reads[Address] = (
    (__ \ "localParts").read[Seq[String]] and
      (__ \ "city").read[String] and
      (__ \ "region").readNullable[String] and
      (__ \ "postalCode").readNullable[String] and
      ( __ \ "country").read[String]
    )(Address.apply _)

  implicit def meetingRoomReads: Reads[MeetingRoom] = (
    (__ \ "meetingRoomId").read[String] and
      (__ \ "meetingRoomType").read[String] and
      (__ \ "meetingRoomName").read[String] and
      (__ \ "meetingRoomUrl").read[String]
  )(MeetingRoom.apply _)
}
