package com.pgi.gmsearch.common.domain

import ai.x.play.json.Jsonx
import io.swagger.annotations.{ApiModel, ApiModelProperty}

import scala.annotation.meta.field

object Phone {
  implicit lazy val phoneFormats = Jsonx.formatCaseClassUseDefaults[Phone]
}

@ApiModel(value = "Phone")
case class Phone(
    @(ApiModelProperty @field)(position = 1, required = true)
    number: String,

    @(ApiModelProperty @field)(position = 2, required = true)
    phoneType: Option[String],

    @(ApiModelProperty @field)(position = 3, required = true)
    isDefault: Boolean
)
