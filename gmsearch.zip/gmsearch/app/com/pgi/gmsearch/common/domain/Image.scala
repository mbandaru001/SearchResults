package com.pgi.gmsearch.common.domain

import ai.x.play.json.Jsonx
import io.swagger.annotations.{ApiModel, ApiModelProperty}

import scala.annotation.meta.field

object Image {
  implicit lazy val imageFormats = Jsonx.formatCaseClassUseDefaults[Image]
}

@ApiModel(value = "Image")
case class Image(
                  @(ApiModelProperty @field)(position = 1, required = true)
                  imageUrl: String,

                  @(ApiModelProperty @field)(position = 2, required = true)
                  isDefault: Boolean
                )
