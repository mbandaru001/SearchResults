package com.pgi.gmsearch.common.domain

import io.swagger.annotations.ApiModel
import play.api.libs.json.Json.JsValueWrapper
import play.api.libs.json._

object ApiResponseMetadata {
  implicit val mapWrites: Writes[Map[String, ApiResponseMetadata]] = (map: Map[String, ApiResponseMetadata]) => Json.obj(map.map {
    case (s, o) =>
      val ret: (String, JsValueWrapper) = s.toString -> o.toJsValue
      ret
  }.toSeq: _*)

  // not used
  implicit val mapReads: Reads[Map[String, ApiResponseMetadata]] = {
    Reads.pure(Map.empty[String, ApiResponseMetadata])
  }
}

@ApiModel(value = "Any JSON value", description = "string, boolean, int, long, float, or double")
sealed trait ApiResponseMetadata {
  def toJsValue: JsValue
}

case class StrMetadata(v: String) extends ApiResponseMetadata {
  lazy val js = JsString(v)
  override def toJsValue: JsValue = js
}

case class BoolMetadata(v: Boolean) extends ApiResponseMetadata {
  lazy val js = JsBoolean(v)
  override def toJsValue: JsValue = js
}

case class IntMetadata(v: Int) extends ApiResponseMetadata {
  lazy val js = JsNumber(v)
  override def toJsValue: JsValue = js
}

case class LongMetadata(v: Long) extends ApiResponseMetadata {
  lazy val js = JsNumber(v)
  override def toJsValue: JsValue = js
}

case class FloatMetadata(v: Float) extends ApiResponseMetadata {
  lazy val js = JsNumber(v)
  override def toJsValue: JsValue = js
}

case class DoubleMetadata(v: Double) extends ApiResponseMetadata {
  lazy val js = JsNumber(v)
  override def toJsValue: JsValue = js
}

case class OptionalJsValueMetadata(v: Option[JsValue]) extends ApiResponseMetadata {
  lazy val js = v.getOrElse(JsNull)
  override def toJsValue: JsValue = js
}

case class OptionalStrMetadata(v: Option[String]) extends ApiResponseMetadata {
  lazy val js = v.map(JsString).getOrElse(JsNull)
  override def toJsValue: JsValue = js
}