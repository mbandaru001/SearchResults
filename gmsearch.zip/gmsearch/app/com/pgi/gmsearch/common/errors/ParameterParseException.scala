package com.pgi.gmsearch.common.errors

case class ParameterParseException(msg: String, customFields: Map[String, String] = Map.empty, tags: List[String] = List.empty) extends Exception(msg)
