package com.pgi.gmsearch.common.errors

case class ElasticSearchResultException(msg: String) extends Exception(msg)