package com.pgi.gmsearch.common

object NameOrders {
  final val WesternOrder = "western"
  final val EasternOrder = "eastern"

  final val OwnerNameWesternOrder = "ownerName_westernOrder"
  final val OwnerNameEasternOrder = "ownerName_easternOrder"

  sealed trait NameOrder { def ownerNameField: String }
  case object Western extends NameOrder { final val ownerNameField =  OwnerNameWesternOrder }
  case object Eastern extends NameOrder { final val ownerNameField =  OwnerNameEasternOrder }
}