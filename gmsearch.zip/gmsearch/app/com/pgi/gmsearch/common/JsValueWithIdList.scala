package com.pgi.gmsearch.common

case class JsValueWithIdList(totalCount: Long, items: Seq[JsValueWithId])