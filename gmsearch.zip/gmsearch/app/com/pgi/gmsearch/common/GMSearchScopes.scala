package com.pgi.gmsearch.common

object GMSearchScopes {

  final val GMSearch = "gmsearch"
  final val GMSearch_Internal = "gmsearch.internal"

}
