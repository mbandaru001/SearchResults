package com.pgi.gmsearch.common

case class JsSearchValueWithIdList(totalCount: Long, items: Seq[JsSearchValueWithId])