package com.pgi.gmsearch.meetingrooms.domain

import ai.x.play.json.Jsonx
import com.pgi.gmsearch.common.domain.Image
import io.swagger.annotations.{ApiModel, ApiModelProperty}

import scala.annotation.meta.field

object ApiMeetingRoomDetails {
  implicit lazy val meetingRoomDetailsFormat = Jsonx.formatCaseClassUseDefaults[ApiMeetingRoomDetails]
}

@ApiModel(value = "MeetingRoomDetails")
case class ApiMeetingRoomDetails(
                               @(ApiModelProperty @field)(position = 1, required = true)
                               meetingRoomName: String,

                               @(ApiModelProperty @field)(position = 2, required = true)
                               meetingRoomUrl: String,

                               @(ApiModelProperty @field)(position = 3, required = true)
                               meetingRoomType: String,

                               @(ApiModelProperty @field)(position = 4, required = true)
                               webMeetingServer: String,

                               @(ApiModelProperty @field)(position = 5, required = true)
                               ownerEmail: String,

                               @(ApiModelProperty @field)(position = 6, required = true)
                               ownerGivenName: Option[String] = None,

                               @(ApiModelProperty @field)(position = 7, required = true)
                               ownerFamilyName: Option[String] = None,

                               @(ApiModelProperty @field)(position = 8, required = true)
                               conferenceType: String,

                               @(ApiModelProperty @field)(position = 9, required = true)
                               brandId: Option[String] = None,

                               @(ApiModelProperty @field)(position = 10, required = true)
                               images: Seq[Image] = Seq.empty,

                               @(ApiModelProperty @field)(position = 11, required = true)
                               conferenceId: String,

                               @(ApiModelProperty @field)(position = 12, required = true)
                               defaultLanguageCode: Option[String] = None,

                               @(ApiModelProperty @field)(position = 13, required = true)
                               vrcUrl: Option[String] = None,

                               @(ApiModelProperty @field)(position = 14, required = true)
                               webMeetingServerRegion: String
                             )