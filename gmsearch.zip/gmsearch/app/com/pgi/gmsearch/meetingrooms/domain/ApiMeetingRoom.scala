package com.pgi.gmsearch.meetingrooms.domain

import ai.x.play.json.Jsonx
import com.pgi.gmsearch.meetingrooms.api.routes
import com.pgi.playframework.domain.ApiObject
import io.swagger.annotations.{ApiModel, ApiModelProperty}

import scala.annotation.meta.field

object ApiMeetingRoom {
  final val ResourceType = "MeetingRoom"

  implicit lazy val meetingRoomFormat = Jsonx.formatCaseClass[ApiMeetingRoom]

  def getMeetingRoomUrl(meetingRoomId: String): String = routes.MeetingRoomController.getMeetingRoom(meetingRoomId, Seq.empty).url

  def apply(id: String, details: Option[ApiMeetingRoomDetails]): ApiMeetingRoom =
    ApiMeetingRoom(id, getMeetingRoomUrl(id), details = details)
}

@ApiModel(value = "MeetingRoom")
case class ApiMeetingRoom(
                           @(ApiModelProperty @field)(position = 1, required = true)
                           id: String,

                           @(ApiModelProperty @field)(position = 2, required = true)
                           resourceUri: String,

                           @(ApiModelProperty @field)(position = 3, required = true)
                           resourceType: String = ApiMeetingRoom.ResourceType,

                           @(ApiModelProperty @field)(position = 4, required = false)
                           details: Option[ApiMeetingRoomDetails] = None
                         ) extends ApiObject