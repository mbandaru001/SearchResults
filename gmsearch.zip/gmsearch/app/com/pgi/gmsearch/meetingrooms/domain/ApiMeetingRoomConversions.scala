package com.pgi.gmsearch.meetingrooms.domain

import com.pgi.gmsearch.common.JsValueWithId
import com.pgi.gmsearch.common.domain.{ApiConversions, Image}
import com.pgi.gmsearch.common.errors.ElasticSearchResultException
import com.pgi.playframework.infrastructure.play.PlayLogging
import play.api.libs.functional.syntax._
import play.api.libs.json._

import scala.language.implicitConversions

trait ApiMeetingRoomConversions extends ApiConversions with PlayLogging {
  implicit def convertToMeetingRoom(result: JsValueWithId): ApiMeetingRoom = {
    def meetingRoomReads(id: String): Reads[ApiMeetingRoom] = (
      Reads.pure(id) and
        (
          (__ \ "meetingRoomName").read[String] and
            (__ \ "meetingRoomUrlOrig").read[String].orElse((__ \ "meetingRoomUrl").read[String]) and
            (__ \ "meetingRoomType").read[String] and
            (__ \ "webMeetingServer").read[String] and
            (__ \ "ownerEmail").read[String] and
            (__ \ "ownerGivenName").readNullable[String] and
            (__ \ "ownerFamilyName").readNullable[String] and
            (__ \ "conferenceType").read[String] and
            (__ \ "brandId").readNullable[String] and
            (__ \ "profileImageUrls").read[Seq[Image]] and
            (__ \ "conferenceId").read[String] and
            (__ \ "defaultLanguageCode").readNullable[String] and
            (__ \ "vrcUrl").readNullable[String] and
            (__ \ "webMeetingServerRegion").read[String]
          )(ApiMeetingRoomDetails.apply _).map[Option[ApiMeetingRoomDetails]](Some(_))
      )(ApiMeetingRoom.apply(_: String, _: Option[ApiMeetingRoomDetails]))

    result.json match {
      case Some(json) =>
        implicit val jsonMtgRoomReader: Reads[ApiMeetingRoom] = meetingRoomReads(result.id)

        json.validate[ApiMeetingRoom] match {
          case JsSuccess(room, _) => room
          case JsError(ex) =>
            ex.flatMap(e => e._2.map(v => e._1 -> v)).foreach { error =>
              logger.info(s"Error parsing ${error._1.toString()}: ${error._2.message}")
            }
            throw ElasticSearchResultException(s"Could not parse JSON from ElasticSearch: ${json.toString}")
        }
      case _ => ApiMeetingRoom(result.id, None)
    }
  }
}
