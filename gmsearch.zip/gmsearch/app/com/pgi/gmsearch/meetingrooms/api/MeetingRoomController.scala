package com.pgi.gmsearch.meetingrooms.api

import com.pgi.gmsearch.common.SearchObjectTypes.{Contacts, MeetingRooms, SearchObjectType}
import com.pgi.gmsearch.common._
import com.pgi.gmsearch.infrastructure.play.bindables.SearchQueryParam
import com.pgi.gmsearch.meetingrooms.domain.{ApiMeetingRoom, ApiMeetingRoomConversions}
import com.pgi.gmsearch.repository.ElasticSearchRepository
import com.pgi.playframework.api.JsonConversions
import com.pgi.playframework.infrastructure.play.PlayLogging
import com.pgi.playframework.infrastructure.play.essentialactions.{EssentialActionBuilder, GlobalScopes}
import io.swagger.annotations._
import javax.inject.Inject
import javax.ws.rs.{PathParam, QueryParam}
import org.apache.http.HttpStatus
import play.api.Configuration
import play.api.mvc.{AbstractController, ControllerComponents}

import scala.concurrent.ExecutionContext

object MeetingRoomController {
  val MeetingRoomFilters = Map("userGroupId" -> KnownFields.UserGroupId)
}

@Api(value = "meetingRooms")
class MeetingRoomController @Inject()(cc: ControllerComponents, conf: Configuration, essentialActionBuilder: EssentialActionBuilder,
  elasticSearchRepository: ElasticSearchRepository)
  (implicit ec: ExecutionContext) extends AbstractController(cc) with JsonConversions with WithUserGroupId
  with ApiMeetingRoomConversions with PlayLogging {
  final val MeetingRoomUrlSearchField: String = "meetingRoomUrl"

  @ApiOperation(nickname = "getMeetingRoom", value = "Get a meeting room", httpMethod = "GET")
  @ApiResponses(Array(
    new ApiResponse(code = HttpStatus.SC_OK, message = "Meeting room", response = classOf[ApiMeetingRoom]),
    new ApiResponse(code = HttpStatus.SC_NOT_FOUND, message = "Meeting room not found")
  ))
  def getMeetingRoom(@ApiParam(value = "Meeting Room ID") @PathParam("id") id: String,
    @ApiParam(value = "Further search query") @QueryParam("fq") fq: Seq[SearchQueryParam],
    @ApiParam(value = "Only Return IDs") @QueryParam("idsOnly") idsOnly: Boolean) =
    essentialActionBuilder.verifyAuthRequest(GMSearchScopes.GMSearch, GlobalScopes.GMServices_Core) { implicit authRequest =>
      Action.async { implicit request =>
        val userGroupId = getUserGroupId(authRequest)
        elasticSearchRepository.getWithId[ApiMeetingRoom](id, MeetingRooms,
          filterMap = getFilterMap(Set(MeetingRooms), userGroupId,
            searchQueryParams = if (!userGroupId.contains(KnownFieldValues.UserGroupId_Universal)) fq.filterNot(_.key == "userGroupId") else fq),
          idsOnly).map {
          case Some(room) => getJsonResponse(toJson(room), HttpStatus.SC_OK)
          case _ => NotFound
        }.recover {
          case ex: Exception =>
            logger.warn(s"Error occurred while getting meeting room with ID: $id", ex)
            InternalServerError(s"Error occurred while getting meeting room with ID: $id")
        }
      }
    }

  @ApiOperation(nickname = "getMeetingRoomByUrl", value = "Get a meeting room", httpMethod = "GET")
  @ApiResponses(Array(
    new ApiResponse(code = HttpStatus.SC_OK, message = "Meeting room", response = classOf[ApiMeetingRoom]),
    new ApiResponse(code = HttpStatus.SC_NOT_FOUND, message = "Meeting room not found")
  ))
  def getMeetingRoomByUrl(@ApiParam(value = "Meeting Room URL") @QueryParam("url") url: String,
    @ApiParam(value = "Only Return IDs") @QueryParam("idsOnly") idsOnly: Boolean) =
    essentialActionBuilder.verifyAuthRequest(GMSearchScopes.GMSearch, GlobalScopes.GMServices_Core) { implicit authRequest =>
      Action.async { implicit request =>
        elasticSearchRepository.getWithField[ApiMeetingRoom](MeetingRoomUrlSearchField, url,
          MeetingRooms,
          Map.empty,
          idsOnly).map {
          case Some(room) => getJsonResponse(toJson(room), HttpStatus.SC_OK)
          case _ => NotFound
        }.recover {
          case ex: Exception =>
            logger.warn(s"Error occurred while getting meeting room with URL: $url", ex)
            InternalServerError(s"Error occurred while getting meeting room with URL: $url")
        }
      }
    }

  private def getFilterMap(searchObjectTypes: Set[SearchObjectType], userGroupId: Set[String], searchQueryParams: Seq[SearchQueryParam]): Map[FilterField, Set[String]] = {
    val filterMap = if (!userGroupId.contains(KnownFieldValues.UserGroupId_Universal))
      Map(FilterField(MeetingRooms, KnownFields.UserGroupId) -> userGroupId)
    else Map.empty

    filterMap ++ (searchObjectTypes.toList match {
      case MeetingRooms :: Nil => searchQueryParams.flatMap(p =>
        MeetingRoomController.MeetingRoomFilters.get(p.key).map(f => SearchQueryParam(f, p.value))).
        map(p => FilterField(Contacts, p.key) -> p.value).toMap
      case _ => Map.empty[FilterField, Set[String]]
    })
  }
}
